# DYLAN VPN

App VPN Android en Kotlin (Jetpack Compose) par **Devs-Dylan**.

## État
- Interface : Home, Profiles, Settings, Guide, menu latéral
- `DylanVpnService` (VpnService) : demande de permission VPN, création du tunnel TUN
- **Pas encore de core réseau** : il faut brancher Xray / sing-box via l'interface `TunnelEngine`
  (`vpn/TunnelEngine.kt`). Sans core, le bouton Connect affiche une erreur au lieu de couper Internet.

## Compiler sans Android Studio
Chaque push sur `main` lance GitHub Actions : onglet **Actions** → dernier run → artefact **DYLAN_VPN-debug** (APK).

## Compiler en local
Ouvrir dans Android Studio, Sync Gradle, Run.

## Prochaines étapes
1. Intégrer un core (libv2ray / sing-box) et implémenter `TunnelEngine`
2. Importer des configs (vless://, vmess://, trojan://) dans l'onglet Profiles
3. Proxy par application (`addAllowedApplication`)
