# DYLAN VPN

App VPN Android en Kotlin (Jetpack Compose) par **Devs-Dylan**, basée sur le core **Xray**.

## Fonctionnalités
- Import avec choix du type (VLESS, VMess, Trojan, Shadowsocks) ou détection automatique
- Format chiffré `dylan://` (AES-256-GCM), configs verrouillables et liables à un appareil
- Espace Admin (menu ☰) protégé par mot de passe pour générer les configs
- Connexion par identifiant et mot de passe : charge la config par défaut
- Durée de validité (durée ou date fixe), limites de débit (global, montant, par fichier) et priorité
- Test de latence de chaque profil (sans VPN)
- Profils : coller un ou plusieurs liens `vless://`, `vmess://`, `trojan://`, `ss://`
- Transports : TCP, WebSocket, gRPC, HTTPUpgrade, XHTTP · Sécurité : TLS, Reality
- Connexion réelle via `VpnService` + Xray (entrée TUN)
- Vitesse, pics et totaux en direct
- Réglages enregistrés (unité de vitesse, DNS, MTU, niveau de journal)
- Écran Journaux

## Compiler
- **GitHub Actions** : chaque push sur `main` compile l'APK (artefact `DYLAN_VPN-debug`).
- **Android Studio** : ouvrir le dossier, Sync, Run.
Le core Xray (`libv2ray.aar`, ~60 Mo) est téléchargé automatiquement par Gradle dans `app/libs/` au premier build.

## Limites connues
- Le trafic IPv6 n'est pas encore envoyé dans le tunnel.
- Pas de proxy par application, ni d'abonnements, ni de service au premier plan.
- Les liens VLESS sans TLS/Reality sont refusés par Xray.
