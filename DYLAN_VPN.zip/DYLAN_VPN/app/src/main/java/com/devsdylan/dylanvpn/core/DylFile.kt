package com.devsdylan.dylanvpn.core

/**
 * Fichier de configurations .dyl : un fichier texte qui commence par « DYLAN-CONFIG v1 », puis contient
 * une config chiffrée (dylan://...) par ligne. Les lignes vides et celles qui commencent par # sont ignorées.
 */
object DylFile {
    const val EXTENSION = ".dyl"
    const val MIME = "application/x-dylan-config"
    private const val HEADER = "DYLAN-CONFIG v1"

    fun build(lines: List<String>): String =
        HEADER + "\n# Devs-Dylan VPN\n" + lines.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n") + "\n"

    /** Extrait les lignes de config d'un fichier .dyl (ou de n'importe quel texte contenant des liens). */
    fun parse(text: String): List<String> =
        text.removePrefix("\uFEFF")
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("DYLAN-CONFIG") }

    /** Nom de fichier sûr, terminé par .dyl. */
    fun safeName(name: String): String {
        val base = name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_', '.').take(40)
        return (base.ifEmpty { "config" }) + EXTENSION
    }
}
