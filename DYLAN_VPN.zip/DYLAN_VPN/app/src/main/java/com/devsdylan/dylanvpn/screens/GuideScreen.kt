package com.devsdylan.dylanvpn.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun GuideScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A3F5F))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Guide", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("Premiers pas avec DYLAN VPN.", color = Color(0xFFCCD6E5))
            }
        }
        GuideCard(
            "Utilisation",
            "1. Ouvre l'onglet Profils et appuie sur +.\n" +
                "2. Colle ton lien de serveur (vless://, vmess://, trojan:// ou ss://). Tu peux en coller plusieurs, un par ligne.\n" +
                "3. Sélectionne le profil avec le bouton rond.\n" +
                "4. Retourne sur Accueil et appuie sur le bouton ▶. Android te demande d'autoriser le VPN la première fois."
        )
        GuideCard(
            "Liens pris en charge",
            "VLESS, VMess, Trojan et Shadowsocks.\n" +
                "Transports : TCP, WebSocket, gRPC, HTTPUpgrade, XHTTP.\n" +
                "Sécurité : TLS et Reality."
        )
        GuideCard(
            "Bon à savoir",
            "• Un lien VLESS sans TLS ni Reality est refusé par le core Xray.\n" +
                "• Les réglages (DNS, MTU...) s'appliquent à la prochaine connexion.\n" +
                "• L'onglet Journaux du menu ☰ affiche les détails en cas d'erreur.\n" +
                "• Le trafic IPv6 n'est pas encore envoyé dans le tunnel."
        )
    }
}

@Composable
private fun GuideCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(body, color = Color(0xFFCCCCCC))
        }
    }
}
