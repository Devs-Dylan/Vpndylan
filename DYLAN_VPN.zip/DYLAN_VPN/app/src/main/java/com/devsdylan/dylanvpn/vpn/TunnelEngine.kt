package com.devsdylan.dylanvpn.vpn

import android.os.ParcelFileDescriptor

/**
 * Interface à implémenter avec un vrai core (Xray, sing-box, libv2ray...).
 * Le core lit/écrit les paquets du tunnel TUN et les envoie vers le serveur.
 */
interface TunnelEngine {
    fun start(tun: ParcelFileDescriptor, config: String)
    fun stop()
}

/** À remplacer par ton implémentation quand le core sera intégré. */
object EngineProvider {
    var engine: TunnelEngine? = null
}
