package com.devsdylan.dylanvpn.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

object Pal {
    val Bg = Color(0xFF070B0A)
    val Bar = Color(0xFF0A0F0E)
    val Card = Color(0xFF0D1513)
    val CardHi = Color(0xFF13201B)
    val Line = Color(0xFF1B2A25)
    val Accent = Color(0xFF4ADE80)
    val Green = Color(0xFF4ADE80)
    val Teal = Color(0xFF0F5C63)
    val Amber = Color(0xFFE3B341)
    val AmberBg = Color(0xFF211B0B)
    val Red = Color(0xFFF0645B)
    val RedBg = Color(0xFF2A1A1E)
    val Text = Color(0xFFE6EDE9)
    val Sub = Color(0xFF8A9A94)
    val Mono = FontFamily.Monospace
}
