package com.devsdylan.dylanvpn.ui

import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF0B0F14)
    val Bar = Color(0xFF10161D)
    val Card = Color(0xFF151B23)
    val CardHi = Color(0xFF1E2733)
    val Accent = Color(0xFF4FC3F7)
    val Green = Color(0xFF3DDC84)
    val Amber = Color(0xFFFFB300)
    val Red = Color(0xFFFF6B6B)
    val RedBg = Color(0xFF2A1A1E)
    val Text = Color(0xFFE6EDF3)
    val Sub = Color(0xFF8B98A9)
}
