package com.devsdylan.dylanvpn.data

import com.devsdylan.dylanvpn.core.Secrets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Session administrateur : valable jusqu'à la fermeture de l'application ou la déconnexion. */
object AdminSession {
    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked

    private var failures = 0
    private var lockedUntil = 0L

    /** Retourne un message d'erreur, ou null si la connexion réussit. */
    fun login(password: String): String? {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) {
            return "Trop d'essais. Réessaie dans " + ((lockedUntil - now) / 1000 + 1) + " s"
        }
        return if (Secrets.checkAdmin(password)) {
            failures = 0
            _unlocked.value = true
            null
        } else {
            failures++
            if (failures >= 5) {
                failures = 0
                lockedUntil = now + 60_000
            }
            "Mot de passe incorrect"
        }
    }

    fun logout() {
        _unlocked.value = false
    }
}
