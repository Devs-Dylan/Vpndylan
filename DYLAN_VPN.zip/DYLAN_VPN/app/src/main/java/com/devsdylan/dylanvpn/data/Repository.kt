package com.devsdylan.dylanvpn.data

import com.devsdylan.dylanvpn.BuildConfig
import com.devsdylan.dylanvpn.core.DylanFormat
import com.devsdylan.dylanvpn.core.GitHubClient
import com.devsdylan.dylanvpn.core.GitHubException
import com.devsdylan.dylanvpn.core.Keyring
import com.devsdylan.dylanvpn.core.RepoService
import com.devsdylan.dylanvpn.core.Secrets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class SyncStatus(val running: Boolean = false, val lastOk: Long = 0, val message: String = "")

/** Dépôt Git privé : utilisateurs et configs par catégorie (basic, pro, admin). */
object Repository {
    const val OWNER = "Devs-Dylan"
    const val REPO = "Vpndylan"
    const val BRANCH = "vpn-data"

    private val _status = MutableStateFlow(SyncStatus())
    val status: StateFlow<SyncStatus> = _status

    // ----- jetons -----

    fun writeToken(): String = SecureStore.get("git_write_token") ?: ""

    fun hasWriteToken(): Boolean = writeToken().isNotBlank()

    fun setWriteToken(token: String?) {
        val clean = token?.trim().orEmpty()
        SecureStore.put("git_write_token", if (clean.isEmpty()) null else clean)
    }

    private fun client(token: String) = GitHubClient(OWNER, REPO, BRANCH, token)

    /** Lecture : le jeton d'écriture s'il existe (admin), sinon le jeton de lecture intégré à l'application. */
    fun readService(): RepoService = RepoService(client(writeToken().ifEmpty { BuildConfig.GIT_READ_TOKEN }))

    private fun writeService(): RepoService {
        val token = writeToken()
        if (token.isBlank()) {
            throw IllegalStateException("Ajoute d'abord le jeton GitHub d'écriture (onglet Dépôt Git)")
        }
        return RepoService(client(token))
    }

    // ----- synchronisation -----

    fun syncAsync() {
        Thread { sync() }.start()
    }

    /** Télécharge les configs de la catégorie du compte. Retourne un message d'erreur, ou null. */
    @Synchronized
    fun sync(): String? {
        val session = Account.session.value ?: return "Non connecté"
        _status.value = _status.value.copy(running = true)
        val problem: String? = try {
            val service = readService()
            val users = service.fetchUsers()
                ?: throw IllegalStateException("Le dépôt de configs n'est pas encore initialisé par l'administrateur")
            if (!Account.verify(users.lines)) throw IllegalStateException("Session fermée")
            val key = Account.keys[session.category]
                ?: throw IllegalStateException("Clé de catégorie absente : reconnecte-toi en ligne")
            val lines = service.readCategory(session.category, key)
            Store.applySync(lines)
            AppLog.i("Synchronisation : " + lines.size + " config(s) (" + session.category + ")")
            _status.value = SyncStatus(false, System.currentTimeMillis(), "Synchronisé à " + clock() + " · " + lines.size + " config(s)")
            null
        } catch (e: GitHubException) {
            e.message
        } catch (e: IllegalStateException) {
            e.message
        }
        if (problem != null) {
            AppLog.w("Synchronisation : $problem")
            _status.value = SyncStatus(false, _status.value.lastOk, problem)
        }
        return problem
    }

    private fun clock(): String = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date())

    // ----- administration (catégorie admin uniquement) -----

    private fun adminKeys(): Map<String, ByteArray> {
        if (!Account.isAdmin) throw IllegalStateException("Réservé à l'administrateur")
        val keys = Account.keys
        if (!keys.keys.containsAll(Keyring.CATEGORIES)) {
            throw IllegalStateException("Clés admin absentes : initialise le dépôt ou reconnecte-toi en ligne")
        }
        return keys
    }

    fun checkAccess(): String {
        val token = writeToken().ifEmpty { BuildConfig.GIT_READ_TOKEN }
        return client(token).checkAccess()
    }

    /** Crée la branche de données, les comptes intégrés et les trois fichiers de catégories. */
    fun initialize(passwords: Map<String, String>): String {
        if (!Account.isAdmin) throw IllegalStateException("Réservé à l'administrateur")
        val accounts = listOf(Pair("basic", "basic"), Pair("power", "pro"), Pair("admin", "admin"))
        for ((login, category) in accounts) {
            val pw = passwords[login].orEmpty()
            if (Secrets.builtinCategory(login, pw) != category) {
                throw IllegalArgumentException("Mot de passe incorrect pour le compte « $login »")
            }
        }
        val service = writeService()
        val seed = Secrets.loadDefault("power", passwords.getValue("power"))
            ?.let { listOf(DylanFormat.encode(it)) } ?: emptyList()
        val keys = service.initialize(accounts.map { Triple(it.first, it.second, passwords.getValue(it.first)) }, seed)
        val adminLine = service.fetchUsers()?.lines?.firstOrNull { it.login == "admin" }
        if (Account.session.value?.login == "admin") Account.updateKeys(keys, adminLine)
        AppLog.i("Dépôt initialisé")
        return "Dépôt initialisé : comptes basic, power et admin créés"
    }

    fun listUsers(): List<Keyring.UserLine> = readService().fetchUsers()?.lines ?: emptyList()

    fun addUser(login: String, password: String, category: String) {
        writeService().addUser(login, password, category, adminKeys())
        AppLog.i("Utilisateur créé : " + Keyring.normalizeLogin(login) + " ($category)")
    }

    fun removeUser(login: String) {
        writeService().removeUser(login)
        AppLog.i("Utilisateur supprimé : " + Keyring.normalizeLogin(login))
    }

    fun readCategory(category: String): List<String> =
        readService().readCategory(category, adminKeys().getValue(category))

    /** Publie une config (lien dylan://) dans une catégorie. Retourne false si elle y était déjà. */
    fun publishConfig(category: String, line: String): Boolean {
        val added = writeService().addConfig(category, adminKeys().getValue(category), line)
        if (added) AppLog.i("Config publiée dans $category")
        return added
    }

    fun removeConfig(category: String, index: Int) {
        writeService().removeConfig(category, adminKeys().getValue(category), index)
        AppLog.i("Config supprimée de $category")
    }
}
