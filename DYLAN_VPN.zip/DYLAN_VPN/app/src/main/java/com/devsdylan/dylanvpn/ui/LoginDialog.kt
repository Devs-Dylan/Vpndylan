package com.devsdylan.dylanvpn.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.devsdylan.dylanvpn.data.Store

/** Connexion par identifiant et mot de passe : charge la configuration par défaut. */
@Composable
fun LoginDialog(onDismiss: () -> Unit, onSuccess: () -> Unit) {
    val context = LocalContext.current
    var login by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Connexion") },
        text = {
            Column {
                Text("Saisis ton identifiant et ton mot de passe pour charger ta configuration.", color = Pal.Sub)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = login,
                    onValueChange = {
                        login = it
                        error = ""
                    },
                    label = { Text("Identifiant") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        error = ""
                    },
                    label = { Text("Mot de passe") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = Pal.Red)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val problem = Store.loginWithCredentials(login, password)
                if (problem == null) {
                    Toast.makeText(context, "Configuration chargée", Toast.LENGTH_SHORT).show()
                    onSuccess()
                } else {
                    error = problem
                }
            }) { Text("Valider") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Plus tard") }
        }
    )
}
