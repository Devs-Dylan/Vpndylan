package com.devsdylan.dylanvpn.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import android.widget.Toast
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import libv2ray.Libv2ray

@Composable
fun AboutScreen() {
    val coreVersion = remember {
        try {
            Libv2ray.checkVersionX()
        } catch (t: Throwable) {
            "indisponible"
        }
    }
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("DYLAN VPN", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("Version 1.0.0", color = Color.Gray)
        Text("Core : $coreVersion", color = Color.Gray)
        Text("Par Devs-Dylan · 2026", color = Color.Gray)
        Text("ID de l'appareil", color = Color.Gray)
        Text(Store.deviceId(), color = Pal.Accent, style = MaterialTheme.typography.titleMedium)
        TextButton(onClick = {
            clipboard.setText(AnnotatedString(Store.deviceId()))
            Toast.makeText(context, "ID copié", Toast.LENGTH_SHORT).show()
        }) { Text("Copier l'ID") }
    }
}
