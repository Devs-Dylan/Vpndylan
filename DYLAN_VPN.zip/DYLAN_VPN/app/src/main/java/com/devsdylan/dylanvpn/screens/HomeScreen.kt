package com.devsdylan.dylanvpn.screens

import android.app.Activity
import android.net.VpnService
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.util.Format
import com.devsdylan.dylanvpn.vpn.DylanVpnService
import com.devsdylan.dylanvpn.vpn.VpnState
import com.devsdylan.dylanvpn.vpn.VpnStatus

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val vpn by VpnState.state.collectAsStateWithLifecycle()
    val profiles by Store.profiles.collectAsStateWithLifecycle()
    val selectedId by Store.selectedId.collectAsStateWithLifecycle()
    val settings by Store.settings.collectAsStateWithLifecycle()
    val selected = profiles.firstOrNull { it.id == selectedId }
    val connected = vpn.status == VpnStatus.CONNECTED
    val connecting = vpn.status == VpnStatus.CONNECTING

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) DylanVpnService.start(context)
    }

    val onToggle: () -> Unit = {
        if (connected || connecting) {
            DylanVpnService.stop(context)
        } else if (selected == null) {
            Toast.makeText(context, "Ajoute d'abord un profil dans l'onglet Profils", Toast.LENGTH_LONG).show()
        } else {
            val intent = VpnService.prepare(context)
            if (intent != null) permissionLauncher.launch(intent) else DylanVpnService.start(context)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Trafic", color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Réception", color = Color(0xFF4FC3F7))
                        Text(
                            Format.speed(vpn.downSpeed, settings.speedUnit),
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        Text("Pic : " + Format.speed(vpn.downPeak, settings.speedUnit), color = Color.Gray)
                        Text("Total : " + Format.bytes(vpn.downTotal), color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Envoi", color = Color(0xFFFFAB91))
                        Text(
                            Format.speed(vpn.upSpeed, settings.speedUnit),
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        Text("Pic : " + Format.speed(vpn.upPeak, settings.speedUnit), color = Color.Gray)
                        Text("Total : " + Format.bytes(vpn.upTotal), color = Color.Gray)
                    }
                }
                AssistChip(onClick = {}, label = {
                    Text(
                        when (vpn.status) {
                            VpnStatus.IDLE -> "Déconnecté"
                            VpnStatus.CONNECTING -> "Connexion..."
                            VpnStatus.CONNECTED -> "Connecté"
                            VpnStatus.ERROR -> "Erreur"
                        }
                    )
                })
                if (vpn.message.isNotEmpty()) Text(vpn.message, color = Color(0xFFFFAB91))
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Profil actif", color = Color.White)
                if (selected == null) {
                    Text(
                        "Aucun profil. Ajoute un lien vless://, vmess://, trojan:// ou ss:// dans l'onglet Profils.",
                        color = Color.Gray
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(selected.name, color = Color.White, modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = true, onClick = {}, label = { Text(selected.protocol.uppercase()) })
                    }
                    Text(selected.host + ":" + selected.port, color = Color.Gray)
                }
            }
        }

        Spacer(Modifier.weight(1f))

        FloatingActionButton(
            onClick = onToggle,
            modifier = Modifier.align(Alignment.End),
            containerColor = Color(0xFF1976D2)
        ) {
            Icon(
                if (connected || connecting) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = "Connexion"
            )
        }
    }
}
