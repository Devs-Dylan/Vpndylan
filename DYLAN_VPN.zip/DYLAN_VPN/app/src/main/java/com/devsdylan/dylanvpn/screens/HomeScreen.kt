package com.devsdylan.dylanvpn.screens

import android.app.Activity
import android.net.VpnService
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal
import com.devsdylan.dylanvpn.util.Format
import com.devsdylan.dylanvpn.vpn.DylanVpnService
import com.devsdylan.dylanvpn.vpn.VpnState
import com.devsdylan.dylanvpn.vpn.VpnStatus
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(onOpenProfiles: () -> Unit, onOpenLogs: () -> Unit) {
    val context = LocalContext.current
    val vpn by VpnState.state.collectAsStateWithLifecycle()
    val profiles by Store.profiles.collectAsStateWithLifecycle()
    val selectedId by Store.selectedId.collectAsStateWithLifecycle()
    val settings by Store.settings.collectAsStateWithLifecycle()
    val selected = profiles.firstOrNull { it.id == selectedId }
    val status = vpn.status
    val connected = status == VpnStatus.CONNECTED
    val connecting = status == VpnStatus.CONNECTING

    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(status) {
        while (status == VpnStatus.CONNECTED) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) DylanVpnService.start(context)
    }

    val onToggle: () -> Unit = {
        if (connected || connecting) {
            DylanVpnService.stop(context)
        } else if (selected == null) {
            Toast.makeText(context, "Ajoute d'abord un profil dans l'onglet Profils", Toast.LENGTH_LONG).show()
        } else {
            val intent = VpnService.prepare(context)
            if (intent != null) permissionLauncher.launch(intent) else DylanVpnService.start(context)
        }
    }

    val ringColor by animateColorAsState(
        targetValue = when (status) {
            VpnStatus.IDLE -> Pal.CardHi
            VpnStatus.CONNECTING -> Pal.Amber
            VpnStatus.CONNECTED -> Pal.Green
            VpnStatus.ERROR -> Pal.Red
        },
        label = "ring"
    )
    val statusLabel = when (status) {
        VpnStatus.IDLE -> "Déconnecté"
        VpnStatus.CONNECTING -> "Connexion..."
        VpnStatus.CONNECTED -> "Connecté"
        VpnStatus.ERROR -> "Échec de la connexion"
    }
    val subtitle = when (status) {
        VpnStatus.IDLE -> "Appuie sur le bouton pour te connecter"
        VpnStatus.CONNECTING -> "Établissement du tunnel"
        VpnStatus.CONNECTED -> {
            val secs = ((now - vpn.connectedAt) / 1000).coerceAtLeast(0)
            String.format(Locale.US, "%02d:%02d:%02d", secs / 3600, (secs / 60) % 60, secs % 60)
        }
        VpnStatus.ERROR -> "Appuie pour réessayer"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(190.dp)) {
            Box(
                modifier = Modifier
                    .size(190.dp)
                    .clip(CircleShape)
                    .background(ringColor.copy(alpha = 0.10f))
            )
            Box(
                modifier = Modifier
                    .size(148.dp)
                    .clip(CircleShape)
                    .background(ringColor.copy(alpha = 0.22f))
            )
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .clip(CircleShape)
                    .background(ringColor)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (connecting) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 4.dp, modifier = Modifier.size(48.dp))
                } else {
                    Icon(
                        Icons.Default.PowerSettingsNew,
                        contentDescription = "Connexion",
                        tint = if (status == VpnStatus.IDLE) Pal.Accent else Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(statusLabel, style = MaterialTheme.typography.headlineSmall, color = Pal.Text)
        Text(subtitle, color = Pal.Sub)
        Spacer(Modifier.height(20.dp))

        if (status == VpnStatus.ERROR && vpn.message.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Pal.RedBg)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(vpn.message, color = Pal.Red)
                    TextButton(onClick = onOpenLogs) { Text("Voir les journaux") }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenProfiles),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Pal.Card)
        ) {
            if (selected == null) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Aucun profil", color = Pal.Text, style = MaterialTheme.typography.titleMedium)
                    Text("Appuie ici pour en ajouter un.", color = Pal.Sub)
                }
            } else {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Pal.Accent.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(selected.name.trim().take(1).uppercase().ifEmpty { "?" }, color = Pal.Accent)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(selected.name, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (selected.locked) "Config verrouillée" else selected.host + ":" + selected.port, color = Pal.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(selected.protocol.uppercase(), color = Pal.Accent)
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                modifier = Modifier.weight(1f),
                title = "Réception",
                icon = Icons.Default.ArrowDownward,
                tint = Pal.Accent,
                speed = Format.speed(vpn.downSpeed, settings.speedUnit),
                peak = Format.speed(vpn.downPeak, settings.speedUnit),
                total = Format.bytes(vpn.downTotal)
            )
            StatCard(
                modifier = Modifier.weight(1f),
                title = "Envoi",
                icon = Icons.Default.ArrowUpward,
                tint = Pal.Amber,
                speed = Format.speed(vpn.upSpeed, settings.speedUnit),
                peak = Format.speed(vpn.upPeak, settings.speedUnit),
                total = Format.bytes(vpn.upTotal)
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun StatCard(
    modifier: Modifier,
    title: String,
    icon: ImageVector,
    tint: Color,
    speed: String,
    peak: String,
    total: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Card)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(title, color = tint)
            }
            Spacer(Modifier.height(8.dp))
            Text(speed, style = MaterialTheme.typography.titleLarge, color = Pal.Text)
            Spacer(Modifier.height(4.dp))
            Text("Pic : $peak", color = Pal.Sub)
            Text("Total : $total", color = Pal.Sub)
        }
    }
}
