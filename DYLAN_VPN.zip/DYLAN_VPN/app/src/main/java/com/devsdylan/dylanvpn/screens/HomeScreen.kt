package com.devsdylan.dylanvpn.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Stop
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.vpn.DylanVpnService
import com.devsdylan.dylanvpn.vpn.VpnState
import com.devsdylan.dylanvpn.vpn.VpnStatus
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val vpn by VpnState.state.collectAsStateWithLifecycle()
    val connected = vpn.status == VpnStatus.CONNECTED

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) DylanVpnService.start(context)
    }
    val toggle = {
        if (connected) {
            DylanVpnService.stop(context)
        } else {
            val intent = VpnService.prepare(context)
            if (intent != null) permissionLauncher.launch(intent) else DylanVpnService.start(context)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Traffic", color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Download", color = Color(0xFF4FC3F7))
                        Text("0 bps", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Peak 0 bps", color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Upload", color = Color(0xFFFFAB91))
                        Text("0 bps", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Peak 0 bps", color = Color.Gray)
                    }
                }
                AssistChip(onClick = {}, label = {
                    Text(
                        when (vpn.status) {
                            VpnStatus.IDLE -> "Idle"
                            VpnStatus.CONNECTING -> "Connecting..."
                            VpnStatus.CONNECTED -> "Connected"
                            VpnStatus.ERROR -> "Error"
                        }
                    )
                })
                if (vpn.message.isNotEmpty()) Text(vpn.message, color = Color(0xFFFFAB91))
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Main connection", color = Color.White)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Single tunnel", color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = true, onClick = {}, label = { Text("V2Ray") })
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {}) { Text("View") }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        FloatingActionButton(
            onClick = { toggle() },
            modifier = Modifier.align(Alignment.End),
            containerColor = Color(0xFF1976D2)
        ) {
            Icon(if (connected) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = "Connect")
        }
    }
}
