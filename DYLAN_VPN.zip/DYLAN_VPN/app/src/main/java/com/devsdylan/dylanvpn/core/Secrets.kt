package com.devsdylan.dylanvpn.core

import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Secrets de l'application. Le mot de passe admin n'est pas stocké en clair (seulement son empreinte),
 * et la config par défaut n'est stockée que chiffrée avec le login et le mot de passe.
 */
object Secrets {
    private const val ITERATIONS = 100_000
    private const val DEFAULT_SALT = "dylanvpn-default-v1"
    private const val DEFAULT_BLOB = "AUzrDmpEBsfh2aEvbeva48w9MgTEDP5EGQqRMXaMpV86lohYUpO7JF9UpGawmwwOKnwl9kknMIv8fpJOFguNvSwHsvAwZZMGcJI87kzMUlTZwULzNSZ3z1AUJFvGu-PFYE9PqxyLGjo5fS3UmYD-r-vfKaWd-A9RT-_4tWIG_kn45lVPIl3ck93UBCkwPU6VfsRhw8E1CWsS4_35hfSXmxz364O2Xo6by7tZnt9IVWZaUPBwTdVtmzoVS_tCimHIpca-itgrCeTWjHpAA3-bR9Uj8qLBa7HSXw1pfVZCSmSmSAFCWSbMn2zq_cAJqaG3nM2tyyTMaYbzoB3UP9MM3zZcthKuqmZLh5bR28WFzMuBsCXXzhI0bioV6BZU6uakt57h2Dmh0wczjZp461AWLAuLVWe6-08JG90JE5lwlNImZVHkUVipZ3HmNuU2HQ"

    /** Comptes intégrés : identifiant, catégorie, sel et empreinte du mot de passe. */
    private class Builtin(val login: String, val category: String, val salt: String, val hash: String)

    private val builtins = listOf(
        Builtin("basic", "basic", "949be18f304fc5a41d33ee0c54e93c3b", "7ac204f6b9da3758f6250626c67fecd692a9de2b49568a76dc8e57588891abb1"),
        Builtin("power", "pro", "9a2e97e7479bd1863539c3c952e72360", "2e902403cede6dd56f3da19ea30c342790ba7cfcc2a584f8fc993557cc919d46"),
        Builtin("admin", "admin", "245814b8a40668e137707732c34bada3", "77fd75853406a3769d0251c877b8a1ddad048ae640860eac7271ef1d4af8de3f")
    )

    fun pbkdf2(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    /** Catégorie d'un compte intégré si l'identifiant et le mot de passe sont bons, sinon null. */
    fun builtinCategory(login: String, password: String): String? {
        val name = Keyring.normalizeLogin(login)
        val account = builtins.firstOrNull { it.login == name } ?: return null
        val computed = pbkdf2(name + ":" + password, fromHex(account.salt))
        return if (MessageDigest.isEqual(computed, fromHex(account.hash))) account.category else null
    }

    /** Catégorie d'un compte intégré à partir de son identifiant seul (sans vérifier le mot de passe). */
    fun builtinCategoryOf(login: String): String? =
        builtins.firstOrNull { it.login == Keyring.normalizeLogin(login) }?.category

    fun hashAccount(login: String, password: String, salt: ByteArray): String =
        toHex(pbkdf2(Keyring.normalizeLogin(login) + ":" + password, salt))

    fun defaultKey(login: String, password: String): ByteArray =
        pbkdf2(login.trim().lowercase() + ":" + password, DEFAULT_SALT.toByteArray(Charsets.UTF_8))

    /** Config par défaut du compte « power », ou null si le login ou le mot de passe est incorrect. */
    fun loadDefault(login: String, password: String): DylanConfig? =
        DylanFormat.openWith(defaultKey(login, password), DEFAULT_BLOB)

    fun toHex(bytes: ByteArray): String = bytes.joinToString("") { String.format("%02x", it) }

    fun fromHex(hex: String): ByteArray =
        ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
