package com.devsdylan.dylanvpn.core

import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Secrets de l'application. Le mot de passe admin n'est pas stocké en clair (seulement son empreinte),
 * et la config par défaut n'est stockée que chiffrée avec le login et le mot de passe.
 */
object Secrets {
    private const val ITERATIONS = 100_000
    private const val ADMIN_SALT = "fe85b27704f452c96093c8b332a55f7d"
    private const val ADMIN_HASH = "db12b5b91ffbe9ee9f57511526b3fc47ab9af9116e90feefb0ac59161719c8f5"
    private const val DEFAULT_SALT = "dylanvpn-default-v1"
    private const val DEFAULT_BLOB = "AUzrDmpEBsfh2aEvbeva48w9MgTEDP5EGQqRMXaMpV86lohYUpO7JF9UpGawmwwOKnwl9kknMIv8fpJOFguNvSwHsvAwZZMGcJI87kzMUlTZwULzNSZ3z1AUJFvGu-PFYE9PqxyLGjo5fS3UmYD-r-vfKaWd-A9RT-_4tWIG_kn45lVPIl3ck93UBCkwPU6VfsRhw8E1CWsS4_35hfSXmxz364O2Xo6by7tZnt9IVWZaUPBwTdVtmzoVS_tCimHIpca-itgrCeTWjHpAA3-bR9Uj8qLBa7HSXw1pfVZCSmSmSAFCWSbMn2zq_cAJqaG3nM2tyyTMaYbzoB3UP9MM3zZcthKuqmZLh5bR28WFzMuBsCXXzhI0bioV6BZU6uakt57h2Dmh0wczjZp461AWLAuLVWe6-08JG90JE5lwlNImZVHkUVipZ3HmNuU2HQ"

    fun pbkdf2(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun checkAdmin(password: String): Boolean {
        val computed = pbkdf2(password, fromHex(ADMIN_SALT))
        return MessageDigest.isEqual(computed, fromHex(ADMIN_HASH))
    }

    fun defaultKey(login: String, password: String): ByteArray =
        pbkdf2(login.trim().lowercase() + ":" + password, DEFAULT_SALT.toByteArray(Charsets.UTF_8))

    /** Config par défaut, ou null si le login ou le mot de passe est incorrect. */
    fun loadDefault(login: String, password: String): DylanConfig? =
        DylanFormat.openWith(defaultKey(login, password), DEFAULT_BLOB)

    fun toHex(bytes: ByteArray): String = bytes.joinToString("") { String.format("%02x", it) }

    fun fromHex(hex: String): ByteArray =
        ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
