package com.devsdylan.dylanvpn.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.devsdylan.dylanvpn.core.DylFile
import java.io.File

/** Création et partage de fichiers .dyl. */
object DylExport {
    /** Écrit un fichier .dyl dans le cache de l'application et ouvre le partage Android. */
    fun share(context: Context, name: String, lines: List<String>) {
        val file = File(context.cacheDir, "exports/" + DylFile.safeName(name))
        file.parentFile?.mkdirs()
        file.writeText(DylFile.build(lines))
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND)
        send.type = DylFile.MIME
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "Partager le fichier .dyl"))
    }

    /** Contenu à écrire dans un fichier choisi par l'utilisateur (Enregistrer sous). */
    fun content(lines: List<String>): String = DylFile.build(lines)
}
