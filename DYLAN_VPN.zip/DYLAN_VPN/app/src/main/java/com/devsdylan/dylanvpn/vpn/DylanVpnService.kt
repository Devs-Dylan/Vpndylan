package com.devsdylan.dylanvpn.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.devsdylan.dylanvpn.core.CoreRuntime
import com.devsdylan.dylanvpn.core.Shaper
import com.devsdylan.dylanvpn.data.Profile
import com.devsdylan.dylanvpn.util.Format
import com.devsdylan.dylanvpn.data.AppLog
import com.devsdylan.dylanvpn.data.Store
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

class DylanVpnService : VpnService() {

    private val executor = Executors.newSingleThreadExecutor()
    private var statsExecutor: ScheduledExecutorService? = null
    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null
    private var shaper: Shaper? = null

    @Volatile
    private var expiring = false

    @Volatile
    private var running = false

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0

        override fun shutdown(): Long = 0

        override fun onEmitStatus(code: Long, message: String?): Long {
            if (!message.isNullOrBlank()) AppLog.i("Core : $message")
            return 0
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            executor.execute {
                stopTunnel(true)
                stopSelf()
            }
        } else {
            executor.execute { startTunnel() }
        }
        return START_NOT_STICKY
    }

    private fun startTunnel() {
        if (running) return
        val profile = Store.selectedProfile()
        if (profile == null) {
            AppLog.e("Aucun profil sélectionné")
            VpnState.set(VpnStatus.ERROR, "Aucun profil sélectionné")
            stopSelf()
            return
        }
        if (Store.isExpired(profile)) {
            val message = "Cette config a expiré le " + Format.dateTime(profile.expiresAt)
            AppLog.e(message)
            VpnState.set(VpnStatus.ERROR, message)
            stopSelf()
            return
        }
        expiring = false
        VpnState.set(VpnStatus.CONNECTING)
        if (profile.locked) {
            AppLog.i("Connexion au profil « ${profile.name} » (config verrouillée)")
        } else {
            AppLog.i("Connexion au profil « ${profile.name} » (${profile.protocol}, ${profile.host}:${profile.port})")
        }
        try {
            val settings = Store.settings.value
            CoreRuntime.init(applicationContext)
            var shaperPort = 0
            val limits = profile.limits
            if (limits.active) {
                val relay = Shaper(limits)
                shaperPort = relay.start()
                shaper = relay
                AppLog.i("Débit limité par la config (↓ " + Format.limit(limits.downBps) + ", ↑ " + Format.limit(limits.upBps) + ", par fichier " + Format.limit(limits.connBps) + ")")
            }
            val config = CoreRuntime.buildConfig(profile, true, shaperPort)

            val builder = Builder()
                .setSession("DYLAN VPN")
                .setMtu(settings.mtu)
                .addAddress("10.10.14.1", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(settings.dns)
            applyAppRules(builder, settings.appsMode, settings.apps)
            val fd = builder.establish() ?: throw IllegalStateException("Permission VPN refusée")
            tun = fd

            val c = Libv2ray.newCoreController(handler)
            controller = c
            c.startLoop(config, fd.fd)
            if (!c.isRunning) throw IllegalStateException("Le core n'a pas démarré")

            running = true
            VpnState.set(VpnStatus.CONNECTED)
            AppLog.i("Connecté")
            startStats(c, profile)
            if (settings.connCheck) Thread { checkConnection(profile) }.start()
        } catch (t: Throwable) {
            val message = CoreRuntime.scrub(profile, CoreRuntime.friendly(t))
            AppLog.e("Échec de la connexion : $message")
            stopTunnel(false)
            VpnState.set(VpnStatus.ERROR, message)
            stopSelf()
        }
    }

    /** Choix des applications qui passent par le VPN (tunnel par application). */
    private fun applyAppRules(builder: Builder, mode: String, chosen: Set<String>) {
        if (mode == "only" && chosen.isNotEmpty()) {
            // Seules ces applications utilisent le VPN ; la nôtre n'y est pas, donc le core joint le serveur.
            for (pkg in chosen) {
                try {
                    builder.addAllowedApplication(pkg)
                } catch (e: Exception) {
                    AppLog.w("Application ignorée ($pkg) : " + e.message)
                }
            }
            AppLog.i("Tunnel limité à " + chosen.size + " application(s)")
            return
        }
        if (mode == "only") AppLog.w("Aucune application choisie : toutes passent par le VPN")
        if (mode == "except") {
            for (pkg in chosen) {
                try {
                    builder.addDisallowedApplication(pkg)
                } catch (e: Exception) {
                    AppLog.w("Application ignorée ($pkg) : " + e.message)
                }
            }
            if (chosen.isNotEmpty()) AppLog.i(chosen.size.toString() + " application(s) hors du tunnel")
        }
        try {
            // L'application elle-même reste hors du tunnel : c'est ce qui permet au core de joindre le serveur.
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            AppLog.w("Impossible d'exclure l'application du tunnel : " + e.message)
        }
    }

    /** Vérifie que le serveur répond (comme la « vérification de connexion » de NPV Tunnel). */
    private fun checkConnection(profile: Profile) {
        AppLog.i("Vérification de la connexion...")
        try {
            val ms = CoreRuntime.measure(applicationContext, profile)
            AppLog.i("Connexion vérifiée ($ms ms)")
        } catch (t: Throwable) {
            val message = CoreRuntime.scrub(profile, CoreRuntime.friendly(t))
            AppLog.w("Le serveur ne répond pas : $message")
            if (running) VpnState.setWarning("Le serveur ne répond pas. Le trafic peut ne pas passer : essaie une autre config.")
        }
    }

    private fun startStats(c: CoreController, profile: Profile) {
        val ex = Executors.newSingleThreadScheduledExecutor()
        statsExecutor = ex
        ex.scheduleWithFixedDelay({
            try {
                var up = 0L
                var down = 0L
                for (entry in c.queryAllOutboundTrafficStats().split(';')) {
                    val parts = entry.split(',')
                    if (parts.size < 3 || parts[0] != "proxy") continue
                    val value = parts[2].trim().toLongOrNull() ?: continue
                    if (parts[1].contains("up", ignoreCase = true)) {
                        up += value
                    } else if (parts[1].contains("down", ignoreCase = true)) {
                        down += value
                    }
                }
                VpnState.updateTraffic(up, down)
                if (profile.expiresAt > 0 && Store.now() >= profile.expiresAt && !expiring) {
                    expiring = true
                    executor.execute {
                        stopTunnel(false)
                        val message = "Cette config a expiré"
                        AppLog.e(message)
                        VpnState.set(VpnStatus.ERROR, message)
                        stopSelf()
                    }
                }
            } catch (t: Throwable) {
                // le core est peut-être en train de s'arrêter
            }
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun stopTunnel(setIdle: Boolean) {
        running = false
        statsExecutor?.shutdownNow()
        statsExecutor = null
        shaper?.stop()
        shaper = null
        val c = controller
        controller = null
        if (c != null) {
            try {
                c.stopLoop()
            } catch (t: Throwable) {
                AppLog.w("Arrêt du core : ${t.message}")
            }
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        try {
            tun?.close()
        } catch (e: Exception) {
            AppLog.w("Fermeture du tunnel : ${e.message}")
        }
        tun = null
        if (setIdle && VpnState.state.value.status != VpnStatus.ERROR) {
            VpnState.set(VpnStatus.IDLE)
            AppLog.i("Déconnecté")
        }
    }

    override fun onRevoke() {
        executor.execute {
            stopTunnel(true)
            stopSelf()
        }
        super.onRevoke()
    }

    override fun onDestroy() {
        executor.execute { stopTunnel(true) }
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.devsdylan.dylanvpn.STOP"

        fun start(context: Context) {
            context.startService(Intent(context, DylanVpnService::class.java))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, DylanVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}
