package com.devsdylan.dylanvpn.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class DylanVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                disconnect()
                stopSelf()
            }
            else -> connect(intent?.getStringExtra(EXTRA_CONFIG).orEmpty())
        }
        return START_NOT_STICKY
    }

    private fun connect(config: String) {
        val engine = EngineProvider.engine
        if (engine == null) {
            // Sans core, un tunnel couperait tout Internet : on refuse proprement.
            VpnState.set(VpnStatus.ERROR, "Core Xray/sing-box non intégré")
            stopSelf()
            return
        }
        VpnState.set(VpnStatus.CONNECTING)
        try {
            tun = Builder()
                .setSession("DYLAN VPN")
                .setMtu(1500)
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .establish()
            val fd = tun ?: throw IllegalStateException("Tunnel non établi")
            engine.start(fd, config)
            VpnState.set(VpnStatus.CONNECTED)
        } catch (e: Exception) {
            VpnState.set(VpnStatus.ERROR, e.message ?: "Erreur inconnue")
            disconnect()
            stopSelf()
        }
    }

    private fun disconnect() {
        EngineProvider.engine?.stop()
        tun?.close()
        tun = null
        if (VpnState.state.value.status != VpnStatus.ERROR) VpnState.set(VpnStatus.IDLE)
    }

    override fun onRevoke() {
        disconnect()
        super.onRevoke()
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.devsdylan.dylanvpn.STOP"
        const val EXTRA_CONFIG = "config"

        fun start(context: Context, config: String = "") {
            context.startService(Intent(context, DylanVpnService::class.java).putExtra(EXTRA_CONFIG, config))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, DylanVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}
