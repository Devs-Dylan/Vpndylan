package com.devsdylan.dylanvpn.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.devsdylan.dylanvpn.core.ConfigBuilder
import com.devsdylan.dylanvpn.core.LinkParser
import com.devsdylan.dylanvpn.data.AppLog
import com.devsdylan.dylanvpn.data.Store
import go.Seq
import java.net.Inet4Address
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

class DylanVpnService : VpnService() {

    private val executor = Executors.newSingleThreadExecutor()
    private var statsExecutor: ScheduledExecutorService? = null
    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null

    @Volatile
    private var running = false

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0

        override fun shutdown(): Long = 0

        override fun onEmitStatus(code: Long, message: String?): Long {
            if (!message.isNullOrBlank()) AppLog.i("Core : $message")
            return 0
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            executor.execute {
                stopTunnel(true)
                stopSelf()
            }
        } else {
            executor.execute { startTunnel() }
        }
        return START_NOT_STICKY
    }

    private fun startTunnel() {
        if (running) return
        val profile = Store.selectedProfile()
        if (profile == null) {
            AppLog.e("Aucun profil sélectionné")
            VpnState.set(VpnStatus.ERROR, "Aucun profil sélectionné")
            stopSelf()
            return
        }
        VpnState.set(VpnStatus.CONNECTING)
        AppLog.i("Connexion au profil « ${profile.name} » (${profile.protocol}, ${profile.host}:${profile.port})")
        try {
            val link = LinkParser.parse(profile.link)
            val settings = Store.settings.value
            val ip = resolve(link.host)
            val config = ConfigBuilder.build(link, ip, settings.mtu, settings.coreLogLevel)
            initCore()

            val builder = Builder()
                .setSession("DYLAN VPN")
                .setMtu(settings.mtu)
                .addAddress("10.10.14.1", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(settings.dns)
            try {
                // L'application elle-même reste hors du tunnel : c'est ce qui permet au core de joindre le serveur.
                builder.addDisallowedApplication(packageName)
            } catch (e: Exception) {
                AppLog.w("Impossible d'exclure l'application du tunnel : ${e.message}")
            }
            val fd = builder.establish() ?: throw IllegalStateException("Permission VPN refusée")
            tun = fd

            val c = Libv2ray.newCoreController(handler)
            controller = c
            c.startLoop(config, fd.fd)
            if (!c.isRunning) throw IllegalStateException("Le core n'a pas démarré")

            running = true
            VpnState.set(VpnStatus.CONNECTED)
            AppLog.i("Connecté")
            startStats(c)
        } catch (t: Throwable) {
            val message = friendly(t)
            AppLog.e("Échec de la connexion : $message")
            stopTunnel(false)
            VpnState.set(VpnStatus.ERROR, message)
            stopSelf()
        }
    }

    private fun resolve(host: String): String? {
        val isIp = host.contains(':') || host.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}"))
        if (isIp) return null
        val all = InetAddress.getAllByName(host)
        val v4 = all.firstOrNull { it is Inet4Address }
        return (v4 ?: all.first()).hostAddress
    }

    private fun initCore() {
        if (coreReady) return
        Seq.setContext(applicationContext)
        Libv2ray.initCoreEnv(getDir("assets", Context.MODE_PRIVATE).absolutePath, Store.deviceKey())
        coreReady = true
    }

    private fun startStats(c: CoreController) {
        val ex = Executors.newSingleThreadScheduledExecutor()
        statsExecutor = ex
        ex.scheduleWithFixedDelay({
            try {
                var up = 0L
                var down = 0L
                for (entry in c.queryAllOutboundTrafficStats().split(';')) {
                    val parts = entry.split(',')
                    if (parts.size < 3 || parts[0] != "proxy") continue
                    val value = parts[2].trim().toLongOrNull() ?: continue
                    if (parts[1].contains("up", ignoreCase = true)) {
                        up += value
                    } else if (parts[1].contains("down", ignoreCase = true)) {
                        down += value
                    }
                }
                VpnState.updateTraffic(up, down)
            } catch (t: Throwable) {
                // le core est peut-être en train de s'arrêter
            }
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun stopTunnel(setIdle: Boolean) {
        running = false
        statsExecutor?.shutdownNow()
        statsExecutor = null
        val c = controller
        controller = null
        if (c != null) {
            try {
                c.stopLoop()
            } catch (t: Throwable) {
                AppLog.w("Arrêt du core : ${t.message}")
            }
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        try {
            tun?.close()
        } catch (e: Exception) {
            AppLog.w("Fermeture du tunnel : ${e.message}")
        }
        tun = null
        if (setIdle) {
            VpnState.set(VpnStatus.IDLE)
            AppLog.i("Déconnecté")
        }
    }

    private fun friendly(t: Throwable): String {
        val raw = t.message ?: t.javaClass.simpleName
        return when {
            t is UnknownHostException -> "Impossible de résoudre l'adresse du serveur (vérifie ta connexion Internet)"
            t is UnsatisfiedLinkError -> "Le core Xray n'est pas compatible avec ce processeur : $raw"
            raw.contains("without TLS", ignoreCase = true) ->
                "Xray refuse ce lien VLESS : il n'a ni TLS ni Reality. Utilise un lien avec security=tls ou reality."
            else -> raw
        }
    }

    override fun onRevoke() {
        executor.execute {
            stopTunnel(true)
            stopSelf()
        }
        super.onRevoke()
    }

    override fun onDestroy() {
        executor.execute { stopTunnel(true) }
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.devsdylan.dylanvpn.STOP"

        @Volatile
        private var coreReady = false

        fun start(context: Context) {
            context.startService(Intent(context, DylanVpnService::class.java))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, DylanVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}
