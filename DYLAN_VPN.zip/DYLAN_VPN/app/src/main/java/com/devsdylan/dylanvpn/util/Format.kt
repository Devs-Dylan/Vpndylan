package com.devsdylan.dylanvpn.util

import java.util.Locale

object Format {

    /** [unit] = "bps" (bits par seconde) ou "Bps" (octets par seconde). */
    fun speed(bytesPerSecond: Long, unit: String): String {
        return if (unit == "Bps") {
            scale(bytesPerSecond.toDouble(), 1024.0, listOf("B/s", "Ko/s", "Mo/s", "Go/s"))
        } else {
            scale(bytesPerSecond * 8.0, 1000.0, listOf("bps", "Kbps", "Mbps", "Gbps"))
        }
    }

    fun bytes(count: Long): String =
        scale(count.toDouble(), 1024.0, listOf("o", "Ko", "Mo", "Go", "To"))

    private fun scale(value: Double, base: Double, units: List<String>): String {
        var v = value
        var i = 0
        while (v >= base && i < units.size - 1) {
            v /= base
            i++
        }
        return if (i == 0) {
            String.format(Locale.US, "%.0f %s", v, units[i])
        } else {
            String.format(Locale.US, "%.1f %s", v, units[i])
        }
    }
}
