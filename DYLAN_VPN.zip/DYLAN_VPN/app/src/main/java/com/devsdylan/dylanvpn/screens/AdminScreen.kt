package com.devsdylan.dylanvpn.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.core.DylanConfig
import com.devsdylan.dylanvpn.core.DylanFormat
import com.devsdylan.dylanvpn.core.LinkParser
import com.devsdylan.dylanvpn.data.AdminSession
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal

@Composable
fun AdminScreen() {
    val unlocked by AdminSession.unlocked.collectAsStateWithLifecycle()
    if (unlocked) AdminPanel() else AdminLogin()
}

@Composable
private fun AdminLogin() {
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Lock, contentDescription = null, tint = Pal.Accent, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Espace administrateur", style = MaterialTheme.typography.titleLarge, color = Pal.Text)
        Text("Entre le mot de passe pour générer des configs.", color = Pal.Sub)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                error = ""
            },
            label = { Text("Mot de passe admin") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = Pal.Red)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val problem = AdminSession.login(password)
            password = ""
            if (problem != null) error = problem
        }) { Text("Connexion") }
    }
}

@Composable
private fun AdminPanel() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val profiles by Store.profiles.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var device by remember { mutableStateOf("") }
    var locked by remember { mutableStateOf(true) }
    var output by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }

    val onGenerate: () -> Unit = {
        try {
            val line = source.trim()
            if (line.isEmpty()) throw IllegalArgumentException("Colle d'abord un lien source")
            if (DylanFormat.isDylan(line)) {
                throw IllegalArgumentException("Colle un lien vless://, vmess://, trojan:// ou ss:// (pas un lien dylan://)")
            }
            val parsed = LinkParser.parse(line)
            val id = device.trim()
            if (id.isNotEmpty() && !DylanFormat.isValidId(id)) {
                throw IllegalArgumentException("ID d'appareil invalide : format DYL-XXXX-XXXX-XXXX-XXXX")
            }
            val config = DylanConfig(
                name = name.trim().ifBlank { parsed.name },
                link = line,
                locked = locked,
                deviceId = id.uppercase(),
                createdAt = System.currentTimeMillis()
            )
            output = DylanFormat.encode(config)
            error = ""
        } catch (e: IllegalArgumentException) {
            error = e.message ?: "Erreur"
            output = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Pal.Card)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Cet appareil", color = Pal.Sub)
                Text(Store.deviceId(), style = MaterialTheme.typography.titleMedium, color = Pal.Accent)
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(Store.deviceId()))
                    Toast.makeText(context, "ID copié", Toast.LENGTH_SHORT).show()
                }) { Text("Copier l'ID") }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Pal.Card)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Générer une config Dylan", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
                OutlinedTextField(
                    value = source,
                    onValueChange = {
                        source = it
                        error = ""
                    },
                    label = { Text("Lien source (vless, vmess, trojan, ss)") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Row {
                    TextButton(onClick = {
                        val pasted = clipboard.getText()?.text
                        if (!pasted.isNullOrBlank()) {
                            source = pasted
                            error = ""
                        }
                    }) { Text("Coller") }
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("Profil enregistré") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            for (p in profiles) {
                                DropdownMenuItem(
                                    text = { Text(p.name) },
                                    onClick = {
                                        source = p.link
                                        if (name.isBlank()) name = p.name
                                        menuOpen = false
                                    }
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nom de la config (facultatif)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = device,
                    onValueChange = {
                        device = it
                        error = ""
                    },
                    label = { Text("ID de l'appareil autorisé (vide = tous)") },
                    placeholder = { Text("DYL-XXXX-XXXX-XXXX-XXXX") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Verrouiller la config", color = Pal.Text)
                        Text("L'utilisateur ne voit pas les détails du serveur.", color = Pal.Sub)
                    }
                    Switch(checked = locked, onCheckedChange = { locked = it })
                }
                if (error.isNotEmpty()) {
                    Text(error, color = Pal.Red)
                }
                Button(onClick = onGenerate) { Text("Générer") }
            }
        }

        if (output.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Pal.Card)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Config générée", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
                    OutlinedTextField(
                        value = output,
                        onValueChange = {},
                        readOnly = true,
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row {
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(output))
                            Toast.makeText(context, "Config copiée", Toast.LENGTH_SHORT).show()
                        }) { Text("Copier") }
                        TextButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND)
                            send.type = "text/plain"
                            send.putExtra(Intent.EXTRA_TEXT, output)
                            context.startActivity(Intent.createChooser(send, "Partager la config"))
                        }) { Text("Partager") }
                    }
                }
            }
        }

        TextButton(onClick = { AdminSession.logout() }) { Text("Se déconnecter de l'admin") }
    }
}
