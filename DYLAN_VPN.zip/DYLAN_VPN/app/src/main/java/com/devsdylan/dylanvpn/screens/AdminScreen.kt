package com.devsdylan.dylanvpn.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.core.DylanConfig
import com.devsdylan.dylanvpn.core.DylanFormat
import com.devsdylan.dylanvpn.core.LinkParser
import com.devsdylan.dylanvpn.util.Format
import java.security.SecureRandom
import java.util.Calendar
import com.devsdylan.dylanvpn.data.AdminSession
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal

@Composable
fun AdminScreen() {
    val unlocked by AdminSession.unlocked.collectAsStateWithLifecycle()
    if (unlocked) AdminPanel() else AdminLogin()
}

@Composable
private fun AdminLogin() {
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Lock, contentDescription = null, tint = Pal.Accent, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Espace administrateur", style = MaterialTheme.typography.titleLarge, color = Pal.Text)
        Text("Entre le mot de passe pour générer des configs.", color = Pal.Sub)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                error = ""
            },
            label = { Text("Mot de passe admin") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = Pal.Red)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val problem = AdminSession.login(password)
            password = ""
            if (problem != null) error = problem
        }) { Text("Connexion") }
    }
}

@Composable
private fun AdminPanel() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val profiles by Store.profiles.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var device by remember { mutableStateOf("") }
    var locked by remember { mutableStateOf(true) }
    var output by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }

    // validité : 0 = aucune, 1 = durée à partir de l'import, 2 = date de fin fixe
    var expiryMode by remember { mutableStateOf(0) }
    var days by remember { mutableStateOf("") }
    var hours by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var endMs by remember { mutableStateOf(0L) }

    // débits en Ko/s (vide ou 0 = illimité) et priorité : 0 basse, 1 normale, 2 haute
    var downKb by remember { mutableStateOf("") }
    var upKb by remember { mutableStateOf("") }
    var connKb by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(1) }

    val parsedInfo = remember(source) { describeLink(source) }

    val pickDate: () -> Unit = {
        val base = Calendar.getInstance()
        if (endMs > 0) base.timeInMillis = endMs
        DatePickerDialog(
            context,
            { _, y, m, d ->
                val cal = Calendar.getInstance()
                if (endMs > 0) {
                    cal.timeInMillis = endMs
                } else {
                    cal.set(Calendar.HOUR_OF_DAY, 23)
                    cal.set(Calendar.MINUTE, 59)
                }
                cal.set(y, m, d)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                endMs = cal.timeInMillis
            },
            base.get(Calendar.YEAR),
            base.get(Calendar.MONTH),
            base.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
    val pickTime: () -> Unit = {
        val base = Calendar.getInstance()
        if (endMs > 0) base.timeInMillis = endMs
        TimePickerDialog(
            context,
            { _, h, min ->
                val cal = Calendar.getInstance()
                if (endMs > 0) cal.timeInMillis = endMs
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, min)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                endMs = cal.timeInMillis
            },
            base.get(Calendar.HOUR_OF_DAY),
            base.get(Calendar.MINUTE),
            true
        ).show()
    }

    val onGenerate: () -> Unit = {
        try {
            val line = source.trim()
            if (line.isEmpty()) throw IllegalArgumentException("Colle d'abord un lien source")
            if (DylanFormat.isDylan(line)) {
                throw IllegalArgumentException("Colle un lien vless://, vmess://, trojan:// ou ss:// (pas un lien dylan://)")
            }
            val parsed = LinkParser.parse(line)
            val id = device.trim()
            if (id.isNotEmpty() && !DylanFormat.isValidId(id)) {
                throw IllegalArgumentException("ID d'appareil invalide : format DYL-XXXX-XXXX-XXXX-XXXX")
            }

            var durationMs = 0L
            var expiresAt = 0L
            if (expiryMode == 1) {
                val d = days.trim().ifEmpty { "0" }.toLongOrNull()
                val h = hours.trim().ifEmpty { "0" }.toLongOrNull()
                val m = minutes.trim().ifEmpty { "0" }.toLongOrNull()
                if (d == null || h == null || m == null || d < 0 || h < 0 || m < 0) {
                    throw IllegalArgumentException("Durée invalide : saisis des nombres positifs")
                }
                durationMs = d * 86_400_000L + h * 3_600_000L + m * 60_000L
                if (durationMs <= 0) throw IllegalArgumentException("La durée doit être supérieure à zéro")
            } else if (expiryMode == 2) {
                if (endMs <= System.currentTimeMillis()) {
                    throw IllegalArgumentException("Choisis une date de fin dans le futur")
                }
                expiresAt = endMs
            }

            val down = downKb.trim().ifEmpty { "0" }.toLongOrNull()
            val up = upKb.trim().ifEmpty { "0" }.toLongOrNull()
            val conn = connKb.trim().ifEmpty { "0" }.toLongOrNull()
            if (down == null || up == null || conn == null || down < 0 || up < 0 || conn < 0) {
                throw IllegalArgumentException("Débit invalide : saisis des nombres positifs (0 = illimité)")
            }
            val burst = when (priority) {
                0 -> 0L
                2 -> 4L * 1024 * 1024
                else -> 1024L * 1024
            }

            val idBytes = ByteArray(8)
            SecureRandom().nextBytes(idBytes)
            val config = DylanConfig(
                name = name.trim().ifBlank { parsed.name },
                link = line,
                locked = locked,
                deviceId = id.uppercase(),
                createdAt = System.currentTimeMillis(),
                cid = idBytes.joinToString("") { String.format("%02x", it) },
                durationMs = durationMs,
                expiresAt = expiresAt,
                downBps = down * 1024,
                upBps = up * 1024,
                connBps = conn * 1024,
                burst = burst
            )
            output = DylanFormat.encode(config)
            summary = buildString {
                append(if (id.isEmpty()) "Tous les appareils" else "Appareil " + id.uppercase())
                append(" · ").append(if (locked) "verrouillée" else "non verrouillée")
                append("\nValidité : ")
                append(
                    when (expiryMode) {
                        1 -> "durée de " + Format.remaining(durationMs) + " à partir de l'import"
                        2 -> "jusqu'au " + Format.dateTime(expiresAt)
                        else -> "illimitée"
                    }
                )
                append("\nDébit : ↓ ").append(Format.limit(config.downBps))
                append(" · ↑ ").append(Format.limit(config.upBps))
                append(" · par fichier ").append(Format.limit(config.connBps))
            }
            error = ""
        } catch (e: IllegalArgumentException) {
            error = e.message ?: "Erreur"
            output = ""
            summary = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AdminCard {
            Text("Cet appareil", color = Pal.Sub)
            Text(Store.deviceId(), style = MaterialTheme.typography.titleMedium, color = Pal.Accent)
            TextButton(onClick = {
                clipboard.setText(AnnotatedString(Store.deviceId()))
                Toast.makeText(context, "ID copié", Toast.LENGTH_SHORT).show()
            }) { Text("Copier l'ID") }
        }

        AdminCard {
            Text("1. Lien source", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
            OutlinedTextField(
                value = source,
                onValueChange = {
                    source = it
                    error = ""
                },
                label = { Text("Lien (vless, vmess, trojan, ss)") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
            Row {
                TextButton(onClick = {
                    val pasted = clipboard.getText()?.text
                    if (!pasted.isNullOrBlank()) {
                        source = pasted
                        error = ""
                    }
                }) { Text("Coller") }
                Box {
                    TextButton(onClick = { menuOpen = true }) { Text("Profil enregistré") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        for (p in profiles) {
                            DropdownMenuItem(
                                text = { Text(p.name) },
                                onClick = {
                                    source = p.link
                                    if (name.isBlank()) name = p.name
                                    menuOpen = false
                                }
                            )
                        }
                    }
                }
            }
            if (parsedInfo != null) {
                Text(parsedInfo.first, color = if (parsedInfo.second) Pal.Green else Pal.Red)
            }
        }

        AdminCard {
            Text("2. Validité", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = expiryMode == 0, onClick = { expiryMode = 0 }, label = { Text("Illimitée") })
                FilterChip(selected = expiryMode == 1, onClick = { expiryMode = 1 }, label = { Text("Durée") })
                FilterChip(selected = expiryMode == 2, onClick = { expiryMode = 2 }, label = { Text("Date fixe") })
            }
            if (expiryMode == 1) {
                Text("La durée commence à l'import sur l'appareil de l'utilisateur.", color = Pal.Sub)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = days,
                        onValueChange = { days = it },
                        label = { Text("Jours") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = hours,
                        onValueChange = { hours = it },
                        label = { Text("Heures") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minutes,
                        onValueChange = { minutes = it },
                        label = { Text("Minutes") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            if (expiryMode == 2) {
                Text(
                    if (endMs > 0) "Fin : " + Format.dateTime(endMs) else "Aucune date choisie",
                    color = if (endMs > 0) Pal.Accent else Pal.Sub
                )
                Row {
                    TextButton(onClick = pickDate) { Text("Choisir la date") }
                    TextButton(onClick = pickTime) { Text("Choisir l'heure") }
                }
            }
        }

        AdminCard {
            Text("3. Bande passante", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
            Text("En Ko/s. Vide ou 0 = illimité.", color = Pal.Sub)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = downKb,
                    onValueChange = { downKb = it },
                    label = { Text("Descendant") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = upKb,
                    onValueChange = { upKb = it },
                    label = { Text("Montant") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = connKb,
                onValueChange = { connKb = it },
                label = { Text("Vitesse max par fichier (connexion)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Priorité", color = Pal.Text)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = priority == 0, onClick = { priority = 0 }, label = { Text("Basse") })
                FilterChip(selected = priority == 1, onClick = { priority = 1 }, label = { Text("Normale") })
                FilterChip(selected = priority == 2, onClick = { priority = 2 }, label = { Text("Haute") })
            }
            Text(
                "La priorité règle la rafale à pleine vitesse au début de chaque connexion (0, 1 ou 4 Mo) " +
                    "avant d'appliquer la vitesse max par fichier. Les pages web restent rapides, les gros téléchargements sont freinés.",
                color = Pal.Sub
            )
        }

        AdminCard {
            Text("4. Options", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nom de la config (facultatif)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = device,
                onValueChange = {
                    device = it
                    error = ""
                },
                label = { Text("ID de l'appareil autorisé (vide = tous)") },
                placeholder = { Text("DYL-XXXX-XXXX-XXXX-XXXX") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Verrouiller la config", color = Pal.Text)
                    Text("L'utilisateur ne voit pas les détails du serveur.", color = Pal.Sub)
                }
                Switch(checked = locked, onCheckedChange = { locked = it })
            }
            if (error.isNotEmpty()) {
                Text(error, color = Pal.Red)
            }
            Button(onClick = onGenerate) { Text("Générer le lien dylan://") }
        }

        if (output.isNotEmpty()) {
            AdminCard {
                Text("Config générée", style = MaterialTheme.typography.titleMedium, color = Pal.Text)
                Text(summary, color = Pal.Sub)
                OutlinedTextField(
                    value = output,
                    onValueChange = {},
                    readOnly = true,
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Row {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(output))
                        Toast.makeText(context, "Config copiée", Toast.LENGTH_SHORT).show()
                    }) { Text("Copier") }
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND)
                        send.type = "text/plain"
                        send.putExtra(Intent.EXTRA_TEXT, output)
                        context.startActivity(Intent.createChooser(send, "Partager la config"))
                    }) { Text("Partager") }
                }
            }
        }

        TextButton(onClick = { AdminSession.logout() }) { Text("Se déconnecter de l'admin") }
    }
}

@Composable
private fun AdminCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Card)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content()
        }
    }
}

/** Résumé lisible d'un lien collé (texte, valide ?), ou null si rien n'est collé. */
private fun describeLink(text: String): Pair<String, Boolean>? {
    val line = text.trim()
    if (line.isEmpty()) return null
    if (DylanFormat.isDylan(line)) return Pair("Ce lien est déjà au format dylan://", false)
    return try {
        val l = LinkParser.parse(line)
        val p = l.params
        val details = ArrayList<String>()
        details.add(l.protocol.uppercase() + " · " + l.host + ":" + l.port)
        details.add("Transport : " + ((p["type"] ?: "tcp").ifBlank { "tcp" }))
        details.add("Sécurité : " + ((p["security"] ?: "aucune").ifBlank { "aucune" }))
        val sni = p["sni"] ?: p["peer"] ?: ""
        if (sni.isNotBlank()) details.add("SNI : $sni")
        val host = p["host"] ?: ""
        if (host.isNotBlank()) details.add("Host : $host")
        details.add("Nom : " + l.name)
        Pair("Lien lu avec succès\n" + details.joinToString("\n"), true)
    } catch (e: IllegalArgumentException) {
        Pair(e.message ?: "Lien invalide", false)
    }
}
