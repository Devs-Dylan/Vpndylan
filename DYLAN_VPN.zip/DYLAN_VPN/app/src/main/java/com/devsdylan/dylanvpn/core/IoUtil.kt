package com.devsdylan.dylanvpn.core

import java.io.ByteArrayOutputStream
import java.io.InputStream

object IoUtil {
    /** Lit au plus [max] octets (sans utiliser readNBytes, absent des anciennes versions d'Android). */
    fun readLimited(input: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (total < max) {
            val n = input.read(buffer, 0, minOf(buffer.size, max - total))
            if (n < 0) break
            out.write(buffer, 0, n)
            total += n
        }
        return out.toByteArray()
    }
}
