package com.devsdylan.dylanvpn.core

/** Opérations sur le dépôt Git : utilisateurs et fichiers de configs par catégorie. */
class RepoService(private val client: GitHubClient) {

    class UsersState(val lines: List<Keyring.UserLine>, val sha: String?)

    companion object {
        const val USERS = "vpn/users.txt"
        fun categoryPath(category: String) = "vpn/$category.txt"

        fun grantFor(category: String, keys: Map<String, ByteArray>): Keyring.Grant =
            if (category == "admin") {
                Keyring.Grant("admin", keys)
            } else {
                Keyring.Grant(category, mapOf(category to keys.getValue(category)))
            }

        fun validLogin(login: String): Boolean = Regex("[a-z0-9._-]{3,32}").matches(Keyring.normalizeLogin(login))
    }

    /** Liste des utilisateurs, ou null si le dépôt n'est pas encore initialisé. */
    fun fetchUsers(): UsersState? {
        val file = client.getFile(USERS) ?: return null
        return UsersState(Keyring.parseUsers(file.text), file.sha)
    }

    /**
     * Initialise le dépôt : branche de données, comptes intégrés, fichiers de catégories vides.
     * [builtin] = (login, catégorie, mot de passe). Retourne les clés des catégories.
     */
    fun initialize(
        builtin: List<Triple<String, String, String>>,
        seedPro: List<String>
    ): Map<String, ByteArray> {
        client.ensureBranch("main")
        val keys = LinkedHashMap<String, ByteArray>()
        for (category in Keyring.CATEGORIES) keys[category] = Keyring.newKey()
        val lines = builtin.map { (login, category, password) ->
            Keyring.createUserLine(login, password, grantFor(category, keys))
        }
        val users = client.getFile(USERS)
        client.putFile(USERS, Keyring.renderUsers(lines), "Initialisation des utilisateurs", users?.sha)
        for (category in Keyring.CATEGORIES) {
            val content = if (category == "pro") seedPro.joinToString("\n") else ""
            val existing = client.getFile(categoryPath(category))
            client.putFile(
                categoryPath(category),
                Keyring.encryptFile(keys.getValue(category), content),
                "Initialisation $category",
                existing?.sha
            )
        }
        return keys
    }

    fun readCategory(category: String, key: ByteArray): List<String> {
        val file = client.getFile(categoryPath(category)) ?: return emptyList()
        val plain = Keyring.decryptFile(key, file.text)
            ?: throw IllegalStateException("Clé incorrecte pour la catégorie $category")
        return plain.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun writeCategory(category: String, key: ByteArray, lines: List<String>, message: String) {
        val file = client.getFile(categoryPath(category))
        client.putFile(categoryPath(category), Keyring.encryptFile(key, lines.joinToString("\n")), message, file?.sha)
    }

    /** Ajoute une config (ligne dylan://) à une catégorie. Retourne false si elle y était déjà. */
    fun addConfig(category: String, key: ByteArray, line: String): Boolean {
        val lines = readCategory(category, key).toMutableList()
        if (lines.contains(line.trim())) return false
        lines.add(line.trim())
        writeCategory(category, key, lines, "Ajout d'une config ($category)")
        return true
    }

    fun removeConfig(category: String, key: ByteArray, index: Int) {
        val lines = readCategory(category, key).toMutableList()
        if (index !in lines.indices) throw IllegalArgumentException("Config introuvable")
        lines.removeAt(index)
        writeCategory(category, key, lines, "Suppression d'une config ($category)")
    }

    fun addUser(login: String, password: String, category: String, keys: Map<String, ByteArray>) {
        if (!validLogin(login)) throw IllegalArgumentException("Identifiant invalide : 3 à 32 caractères (lettres, chiffres, . _ -)")
        if (password.length < 6) throw IllegalArgumentException("Mot de passe trop court (6 caractères minimum)")
        if (category !in Keyring.CATEGORIES) throw IllegalArgumentException("Catégorie inconnue")
        val state = fetchUsers() ?: throw IllegalStateException("Dépôt non initialisé")
        val name = Keyring.normalizeLogin(login)
        if (state.lines.any { it.login == name }) throw IllegalArgumentException("Cet identifiant existe déjà")
        val line = Keyring.createUserLine(name, password, grantFor(category, keys))
        client.putFile(USERS, Keyring.renderUsers(state.lines + line), "Ajout de l'utilisateur $name", state.sha)
    }

    fun removeUser(login: String) {
        val state = fetchUsers() ?: throw IllegalStateException("Dépôt non initialisé")
        val name = Keyring.normalizeLogin(login)
        val rest = state.lines.filter { it.login != name }
        if (rest.size == state.lines.size) throw IllegalArgumentException("Utilisateur introuvable")
        client.putFile(USERS, Keyring.renderUsers(rest), "Suppression de l'utilisateur $name", state.sha)
    }
}
