package com.devsdylan.dylanvpn.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.devsdylan.dylanvpn.data.Account
import com.devsdylan.dylanvpn.data.Repository
import com.devsdylan.dylanvpn.data.Session
import com.devsdylan.dylanvpn.screens.AboutScreen
import com.devsdylan.dylanvpn.screens.AdminScreen
import com.devsdylan.dylanvpn.screens.AppsScreen
import com.devsdylan.dylanvpn.screens.GuideScreen
import com.devsdylan.dylanvpn.screens.HomeScreen
import com.devsdylan.dylanvpn.screens.LogsScreen
import com.devsdylan.dylanvpn.screens.MoreScreen
import com.devsdylan.dylanvpn.screens.ProfilesScreen
import com.devsdylan.dylanvpn.screens.SettingsScreen
import com.devsdylan.dylanvpn.screens.categoryLabel
import kotlinx.coroutines.launch

@Composable
fun MainNavigation() {
    val session by Account.session.collectAsStateWithLifecycle()
    val current = session
    if (current == null) {
        LoginScreen()
    } else {
        MainContent(current)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainContent(session: Session) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val go: (String) -> Unit = { route -> navController.navigate(route) { launchSingleTop = true } }

    val title = when (currentRoute) {
        "home" -> "Accueil"
        "profiles" -> "Profils"
        "settings" -> "Réglages"
        "more" -> "Plus"
        "guide" -> "Guide"
        "logs" -> "Journaux"
        "about" -> "À propos"
        "admin" -> "Admin"
        "apps" -> "Applications"
        else -> "DYLAN VPN"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Pal.Bar) {
                Text("DYLAN VPN", modifier = Modifier.padding(16.dp), color = Color.White)
                Text(
                    session.login + " · " + categoryLabel(session.category),
                    color = Pal.Accent,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(top = 16.dp))
                NavigationDrawerItem(
                    label = { Text("Journaux") },
                    selected = currentRoute == "logs",
                    onClick = {
                        go("logs")
                        scope.launch { drawerState.close() }
                    }
                )
                if (session.category == "admin") {
                    NavigationDrawerItem(
                        label = { Text("Admin") },
                        selected = currentRoute == "admin",
                        onClick = {
                            go("admin")
                            scope.launch { drawerState.close() }
                        }
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Synchroniser les configs") },
                    selected = false,
                    onClick = {
                        Repository.syncAsync()
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("À propos") },
                    selected = currentRoute == "about",
                    onClick = {
                        go("about")
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("Se déconnecter") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        Account.logout()
                    }
                )
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Pal.Bar) {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = { go("home") },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Accueil") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "profiles",
                        onClick = { go("profiles") },
                        icon = { Icon(Icons.Outlined.List, null) },
                        label = { Text("Profils") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "settings",
                        onClick = { go("settings") },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Réglages") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "more",
                        onClick = { go("more") },
                        icon = { Icon(Icons.Default.MoreHoriz, null) },
                        label = { Text("Plus") }
                    )
                }
            },
            topBar = {
                TopAppBar(
                    title = { Text(title, color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pal.Bar)
                )
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                composable("home") {
                    HomeScreen(
                        onOpenProfiles = { go("profiles") },
                        onOpenLogs = { go("logs") }
                    )
                }
                composable("profiles") { ProfilesScreen() }
                composable("settings") { SettingsScreen() }
                composable("more") { MoreScreen(onNavigate = go) }
                composable("guide") { GuideScreen() }
                composable("logs") { LogsScreen() }
                composable("about") { AboutScreen() }
                composable("admin") { AdminScreen() }
                composable("apps") { AppsScreen() }
            }
        }
    }
}
