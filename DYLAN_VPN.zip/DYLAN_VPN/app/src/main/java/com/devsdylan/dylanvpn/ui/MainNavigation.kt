package com.devsdylan.dylanvpn.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.devsdylan.dylanvpn.screens.AboutScreen
import com.devsdylan.dylanvpn.screens.GuideScreen
import com.devsdylan.dylanvpn.screens.HomeScreen
import com.devsdylan.dylanvpn.screens.LogsScreen
import com.devsdylan.dylanvpn.screens.ProfilesScreen
import com.devsdylan.dylanvpn.screens.SettingsScreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val title = when (currentRoute) {
        "home" -> "Accueil"
        "profiles" -> "Profils"
        "settings" -> "Réglages"
        "guide" -> "Guide"
        "logs" -> "Journaux"
        "about" -> "À propos"
        else -> "DYLAN VPN"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Pal.Bar) {
                Text("DYLAN VPN", modifier = Modifier.padding(16.dp), color = Color.White)
                Text("v1.0.0 · 2026 © Devs-Dylan", color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp))
                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(top = 16.dp))
                NavigationDrawerItem(
                    label = { Text("Journaux") },
                    selected = currentRoute == "logs",
                    onClick = {
                        navController.navigate("logs") { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("À propos") },
                    selected = currentRoute == "about",
                    onClick = {
                        navController.navigate("about") { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Pal.Bar) {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Accueil") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "profiles",
                        onClick = { navController.navigate("profiles") { launchSingleTop = true } },
                        icon = { Icon(Icons.Outlined.List, null) },
                        label = { Text("Profils") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "settings",
                        onClick = { navController.navigate("settings") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Réglages") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "guide",
                        onClick = { navController.navigate("guide") { launchSingleTop = true } },
                        icon = { Icon(Icons.Outlined.Book, null) },
                        label = { Text("Guide") }
                    )
                }
            },
            topBar = {
                TopAppBar(
                    title = { Text(title, color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pal.Bar)
                )
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                composable("home") {
                    HomeScreen(
                        onOpenProfiles = { navController.navigate("profiles") { launchSingleTop = true } },
                        onOpenLogs = { navController.navigate("logs") { launchSingleTop = true } }
                    )
                }
                composable("profiles") { ProfilesScreen() }
                composable("settings") { SettingsScreen() }
                composable("guide") { GuideScreen() }
                composable("logs") { LogsScreen() }
                composable("about") { AboutScreen() }
            }
        }
    }
}
