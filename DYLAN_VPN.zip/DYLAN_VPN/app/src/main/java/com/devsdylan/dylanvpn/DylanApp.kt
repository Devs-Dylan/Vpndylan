package com.devsdylan.dylanvpn

import android.app.Application
import com.devsdylan.dylanvpn.data.Store

class DylanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}
