package com.devsdylan.dylanvpn.data

import android.content.Context
import android.content.SharedPreferences
import com.devsdylan.dylanvpn.core.LinkParser
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Profils et réglages, enregistrés dans les préférences de l'application. */
object Store {
    private const val KEY_PROFILES = "profiles"
    private const val KEY_SELECTED = "selected"
    private const val KEY_DEVICE = "device_key"

    private var prefs: SharedPreferences? = null

    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())
    val profiles: StateFlow<List<Profile>> = _profiles

    private val _selectedId = MutableStateFlow<String?>(null)
    val selectedId: StateFlow<String?> = _selectedId

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("dylanvpn", Context.MODE_PRIVATE)
        prefs = p
        _profiles.value = decodeProfiles(p.getString(KEY_PROFILES, "[]") ?: "[]")
        _selectedId.value = p.getString(KEY_SELECTED, null)
        val d = AppSettings()
        val s = AppSettings(
            speedUnit = p.getString("speed_unit", d.speedUnit) ?: d.speedUnit,
            logLimit = p.getInt("log_limit", d.logLimit),
            mtu = p.getInt("mtu", d.mtu),
            dns = p.getString("dns", d.dns) ?: d.dns,
            coreLogLevel = p.getString("core_log_level", d.coreLogLevel) ?: d.coreLogLevel
        )
        _settings.value = s
        AppLog.limit = s.logLimit
    }

    fun selectedProfile(): Profile? {
        val id = _selectedId.value ?: return null
        return _profiles.value.firstOrNull { it.id == id }
    }

    /** Ajoute un ou plusieurs liens (un par ligne). */
    fun addProfiles(text: String, expectedProtocol: String? = null): AddResult {
        val errors = ArrayList<String>()
        val list = ArrayList(_profiles.value)
        var added = 0
        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            try {
                val link = LinkParser.parse(line)
                if (expectedProtocol != null && link.protocol != expectedProtocol) {
                    errors.add(
                        "Ce lien est de type " + link.protocol.uppercase() +
                            " alors que tu as choisi " + expectedProtocol.uppercase()
                    )
                    continue
                }
                if (list.any { it.link == line }) {
                    errors.add("« ${link.name} » est déjà enregistré")
                    continue
                }
                list.add(
                    Profile(
                        id = UUID.randomUUID().toString(),
                        name = link.name,
                        link = line,
                        protocol = link.protocol,
                        host = link.host,
                        port = link.port
                    )
                )
                added++
            } catch (e: IllegalArgumentException) {
                errors.add(e.message ?: "Lien invalide")
            }
        }
        if (added > 0) {
            _profiles.value = list
            if (selectedProfile() == null) _selectedId.value = list.first().id
            saveProfiles()
        }
        return AddResult(added, errors)
    }

    fun deleteProfile(id: String) {
        val list = _profiles.value.filter { it.id != id }
        _profiles.value = list
        if (_selectedId.value == id) _selectedId.value = list.firstOrNull()?.id
        saveProfiles()
    }

    fun select(id: String) {
        _selectedId.value = id
        prefs?.edit()?.putString(KEY_SELECTED, id)?.apply()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val s = transform(_settings.value)
        _settings.value = s
        AppLog.limit = s.logLimit
        prefs?.edit()
            ?.putString("speed_unit", s.speedUnit)
            ?.putInt("log_limit", s.logLimit)
            ?.putInt("mtu", s.mtu)
            ?.putString("dns", s.dns)
            ?.putString("core_log_level", s.coreLogLevel)
            ?.apply()
    }

    /** Clé aléatoire propre à l'appareil, demandée par le core Xray. */
    fun deviceKey(): String {
        val p = prefs ?: return UUID.randomUUID().toString()
        var key = p.getString(KEY_DEVICE, null)
        if (key == null) {
            key = UUID.randomUUID().toString()
            p.edit().putString(KEY_DEVICE, key).apply()
        }
        return key
    }

    private fun saveProfiles() {
        val arr = JSONArray()
        for (p in _profiles.value) {
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("link", p.link)
                    .put("protocol", p.protocol)
                    .put("host", p.host)
                    .put("port", p.port)
            )
        }
        val editor = prefs?.edit() ?: return
        editor.putString(KEY_PROFILES, arr.toString())
        if (_selectedId.value != null) editor.putString(KEY_SELECTED, _selectedId.value)
        editor.apply()
    }

    private fun decodeProfiles(json: String): List<Profile> {
        val result = ArrayList<Profile>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    Profile(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        link = o.getString("link"),
                        protocol = o.getString("protocol"),
                        host = o.getString("host"),
                        port = o.getInt("port")
                    )
                )
            }
        } catch (e: Exception) {
            // données illisibles : on repart d'une liste vide
        }
        return result
    }
}
