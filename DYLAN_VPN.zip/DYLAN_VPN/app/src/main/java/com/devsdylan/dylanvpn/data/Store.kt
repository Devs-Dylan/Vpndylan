package com.devsdylan.dylanvpn.data

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.devsdylan.dylanvpn.core.DylanConfig
import com.devsdylan.dylanvpn.core.DylanFormat
import com.devsdylan.dylanvpn.core.LinkParser
import com.devsdylan.dylanvpn.core.Secrets
import java.security.SecureRandom
import java.util.Base64
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Profils et réglages, enregistrés dans les préférences de l'application. */
object Store {
    private const val KEY_PROFILES = "profiles"
    private const val KEY_SELECTED = "selected"
    private const val KEY_DEVICE = "device_key_v2"

    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null

    private val _firstRunDone = MutableStateFlow(true)
    val firstRunDone: StateFlow<Boolean> = _firstRunDone

    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())
    val profiles: StateFlow<List<Profile>> = _profiles

    private val _selectedId = MutableStateFlow<String?>(null)
    val selectedId: StateFlow<String?> = _selectedId

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("dylanvpn", Context.MODE_PRIVATE)
        prefs = p
        appContext = context.applicationContext
        _firstRunDone.value = p.getBoolean("first_run_done", false)
        _profiles.value = decodeProfiles(p.getString(KEY_PROFILES, "[]") ?: "[]")
        _selectedId.value = p.getString(KEY_SELECTED, null)
        val d = AppSettings()
        val s = AppSettings(
            speedUnit = p.getString("speed_unit", d.speedUnit) ?: d.speedUnit,
            logLimit = p.getInt("log_limit", d.logLimit),
            mtu = p.getInt("mtu", d.mtu),
            dns = p.getString("dns", d.dns) ?: d.dns,
            coreLogLevel = p.getString("core_log_level", d.coreLogLevel) ?: d.coreLogLevel
        )
        _settings.value = s
        AppLog.limit = s.logLimit
    }

    fun selectedProfile(): Profile? {
        val id = _selectedId.value ?: return null
        return _profiles.value.firstOrNull { it.id == id }
    }

    /** Identifiant de cet appareil (DYL-XXXX-XXXX-XXXX-XXXX), à communiquer à l'administrateur. */
    fun deviceId(): String {
        val ctx = appContext ?: return "DYL-INCONNU"
        val raw = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (e: Exception) {
            null
        } ?: "inconnu"
        return DylanFormat.deviceIdFromRaw(raw)
    }

    /** Ajoute un ou plusieurs liens (un par ligne) : vless, vmess, trojan, ss ou dylan. */
    fun addProfiles(text: String, expectedProtocol: String? = null): AddResult {
        val errors = ArrayList<String>()
        val list = ArrayList(_profiles.value)
        var added = 0
        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            try {
                var linkText = line
                var locked = false
                var nameOverride = ""
                if (DylanFormat.isDylan(line)) {
                    if (expectedProtocol != null && expectedProtocol != "dylan") {
                        errors.add("Ce lien est de type DYLAN alors que tu as choisi " + expectedProtocol.uppercase())
                        continue
                    }
                    val cfg = DylanFormat.decode(line)
                    if (cfg.deviceId.isNotBlank() &&
                        DylanFormat.normalizeId(cfg.deviceId) != DylanFormat.normalizeId(deviceId())
                    ) {
                        errors.add("Cette config est réservée à un autre appareil. ID de cet appareil : " + deviceId())
                        continue
                    }
                    linkText = cfg.link
                    locked = cfg.locked
                    nameOverride = cfg.name
                } else if (expectedProtocol == "dylan") {
                    errors.add("Ce n'est pas un lien dylan://")
                    continue
                }
                val link = LinkParser.parse(linkText)
                if (expectedProtocol != null && expectedProtocol != "dylan" && link.protocol != expectedProtocol) {
                    errors.add(
                        "Ce lien est de type " + link.protocol.uppercase() +
                            " alors que tu as choisi " + expectedProtocol.uppercase()
                    )
                    continue
                }
                val name = nameOverride.ifBlank { link.name }
                if (list.any { it.link == linkText }) {
                    errors.add("« $name » est déjà enregistré")
                    continue
                }
                list.add(
                    Profile(
                        id = UUID.randomUUID().toString(),
                        name = name,
                        link = linkText,
                        protocol = link.protocol,
                        host = link.host,
                        port = link.port,
                        locked = locked
                    )
                )
                added++
            } catch (e: IllegalArgumentException) {
                errors.add(e.message ?: "Lien invalide")
            }
        }
        if (added > 0) {
            _profiles.value = list
            if (selectedProfile() == null) _selectedId.value = list.first().id
            saveProfiles()
        }
        return AddResult(added, errors)
    }

    /** Connexion par login et mot de passe : charge la config par défaut. Retourne un message d'erreur, ou null. */
    fun loginWithCredentials(login: String, password: String): String? {
        val cfg = Secrets.loadDefault(login, password) ?: return "Identifiant ou mot de passe incorrect"
        val line = DylanFormat.encode(cfg)
        val existing = _profiles.value.firstOrNull { it.link == cfg.link }
        if (existing != null) {
            select(existing.id)
        } else {
            val result = addProfiles(line)
            if (result.added == 0) return result.errors.firstOrNull() ?: "Impossible de charger la configuration"
            val added = _profiles.value.firstOrNull { it.link == cfg.link }
            if (added != null) select(added.id)
        }
        markFirstRunDone()
        return null
    }

    fun markFirstRunDone() {
        _firstRunDone.value = true
        prefs?.edit()?.putBoolean("first_run_done", true)?.apply()
    }

    fun deleteProfile(id: String) {
        val list = _profiles.value.filter { it.id != id }
        _profiles.value = list
        if (_selectedId.value == id) _selectedId.value = list.firstOrNull()?.id
        saveProfiles()
    }

    fun select(id: String) {
        _selectedId.value = id
        prefs?.edit()?.putString(KEY_SELECTED, id)?.apply()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val s = transform(_settings.value)
        _settings.value = s
        AppLog.limit = s.logLimit
        prefs?.edit()
            ?.putString("speed_unit", s.speedUnit)
            ?.putInt("log_limit", s.logLimit)
            ?.putInt("mtu", s.mtu)
            ?.putString("dns", s.dns)
            ?.putString("core_log_level", s.coreLogLevel)
            ?.apply()
    }

    /** Clé propre à l'appareil demandée par le core Xray : 32 octets aléatoires en base64 URL sans remplissage. */
    fun deviceKey(): String {
        val p = prefs ?: return randomDeviceKey()
        var key = p.getString(KEY_DEVICE, null)
        if (key == null) {
            key = randomDeviceKey()
            p.edit().putString(KEY_DEVICE, key).apply()
        }
        return key
    }

    private fun randomDeviceKey(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }

    private fun saveProfiles() {
        val arr = JSONArray()
        for (p in _profiles.value) {
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("link", p.link)
                    .put("protocol", p.protocol)
                    .put("host", p.host)
                    .put("port", p.port)
                    .put("locked", p.locked)
            )
        }
        val editor = prefs?.edit() ?: return
        editor.putString(KEY_PROFILES, arr.toString())
        if (_selectedId.value != null) editor.putString(KEY_SELECTED, _selectedId.value)
        editor.apply()
    }

    private fun decodeProfiles(json: String): List<Profile> {
        val result = ArrayList<Profile>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    Profile(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        link = o.getString("link"),
                        protocol = o.getString("protocol"),
                        host = o.getString("host"),
                        port = o.getInt("port"),
                        locked = o.optBoolean("locked", false)
                    )
                )
            }
        } catch (e: Exception) {
            // données illisibles : on repart d'une liste vide
        }
        return result
    }
}
