package com.devsdylan.dylanvpn.core

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

/**
 * Trousseau de clés des catégories.
 *  - Chaque catégorie (basic, pro, admin) a une clé AES aléatoire qui chiffre son fichier de configs.
 *  - Pour chaque utilisateur, la ou les clés auxquelles il a droit sont « enveloppées » avec une clé
 *    dérivée de son identifiant et de son mot de passe (PBKDF2). Sans le bon mot de passe, impossible
 *    d'ouvrir l'enveloppe : le dépôt ne contient aucun mot de passe.
 */
object Keyring {
    const val ITERATIONS = 150_000
    val CATEGORIES = listOf("basic", "pro", "admin")

    data class UserLine(val login: String, val category: String, val salt: String, val blob: String)

    class Grant(val category: String, val keys: Map<String, ByteArray>)

    fun newKey(): ByteArray {
        val key = ByteArray(32)
        SecureRandom().nextBytes(key)
        return key
    }

    fun normalizeLogin(login: String): String = login.trim().lowercase()

    fun createUserLine(login: String, password: String, grant: Grant): UserLine {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val keysJson = JSONObject()
        for ((name, key) in grant.keys) keysJson.put(name, b64(key))
        val payload = JSONObject().put("c", grant.category).put("k", keysJson).toString().toByteArray(Charsets.UTF_8)
        val login0 = normalizeLogin(login)
        val sealed = gcmEncrypt(deriveKey(login0, password, salt), aad(login0, grant.category), payload)
        return UserLine(login0, grant.category, b64(salt), b64(sealed))
    }

    /** Ouvre l'enveloppe d'un utilisateur ; null si le mot de passe est faux. */
    fun unwrap(line: UserLine, password: String): Grant? {
        return try {
            val key = deriveKey(line.login, password, unb64(line.salt))
            val plain = gcmDecrypt(key, aad(line.login, line.category), unb64(line.blob)) ?: return null
            val json = JSONObject(String(plain, Charsets.UTF_8))
            val keysJson = json.optJSONObject("k") ?: return null
            val keys = LinkedHashMap<String, ByteArray>()
            val names = keysJson.keys()
            while (names.hasNext()) {
                val name = names.next()
                keys[name] = unb64(keysJson.optString(name, ""))
            }
            Grant(json.optString("c", line.category), keys)
        } catch (e: Exception) {
            null
        }
    }

    // ----- fichier des utilisateurs : une ligne « login|catégorie|sel|enveloppe » -----

    fun parseUsers(text: String): List<UserLine> {
        val out = ArrayList<UserLine>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val parts = line.split('|')
            if (parts.size != 4) continue
            out.add(UserLine(parts[0], parts[1], parts[2], parts[3]))
        }
        return out
    }

    fun renderUsers(lines: List<UserLine>): String =
        "# DYLAN VPN - utilisateurs (login|categorie|sel|enveloppe)\n" +
            lines.joinToString("\n") { it.login + "|" + it.category + "|" + it.salt + "|" + it.blob } + "\n"

    // ----- fichiers de catégorie -----

    fun encryptFile(key: ByteArray, plain: String): String =
        b64(gcmEncrypt(key, FILE_AAD, plain.toByteArray(Charsets.UTF_8)))

    fun decryptFile(key: ByteArray, text: String): String? =
        try {
            gcmDecrypt(key, FILE_AAD, unb64(text.trim()))?.let { String(it, Charsets.UTF_8) }
        } catch (e: Exception) {
            null
        }

    // ----- interne -----

    private val FILE_AAD = "dylan-file-v1".toByteArray(Charsets.UTF_8)

    private fun aad(login: String, category: String): ByteArray =
        ("dylan-user|" + login + "|" + category).toByteArray(Charsets.UTF_8)

    private fun deriveKey(login: String, password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec((login + ":" + password).toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun gcmEncrypt(key: ByteArray, aad: ByteArray, plain: ByteArray): ByteArray {
        val iv = ByteArray(12)
        SecureRandom().nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad)
        return iv + cipher.doFinal(plain)
    }

    private fun gcmDecrypt(key: ByteArray, aad: ByteArray, data: ByteArray): ByteArray? {
        if (data.size < 12 + 16) return null
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, data.copyOfRange(0, 12)))
            cipher.updateAAD(aad)
            cipher.doFinal(data, 12, data.size - 12)
        } catch (e: Exception) {
            null
        }
    }

    private fun b64(bytes: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)

    private fun unb64(text: String): ByteArray = Base64.getUrlDecoder().decode(text.trim())
}
