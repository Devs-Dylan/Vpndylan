package com.devsdylan.dylanvpn.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text("General", color = Color(0xFF4FC3F7), modifier = Modifier.padding(16.dp))
            ListItem(headlineContent = { Text("Language") }, supportingContent = { Text("System default") })
            ListItem(headlineContent = { Text("Dynamic color") }, supportingContent = { Text("Use the system color palette") }, trailingContent = { Switch(checked = false, onCheckedChange = {}) })
            ListItem(headlineContent = { Text("Theme colors") }, supportingContent = { Text("Choose the app theme color") })
            ListItem(headlineContent = { Text("Theme mode") }, supportingContent = { Text("System default") })
            ListItem(headlineContent = { Text("Log filter") }, supportingContent = { Text("Normal") })
            ListItem(headlineContent = { Text("Log entry limit") }, supportingContent = { Text("1000 entries") })
            ListItem(headlineContent = { Text("Speed unit") }, supportingContent = { Text("Bit/s (bps)") })
        }
        item {
            Text("Connection", color = Color(0xFF4FC3F7), modifier = Modifier.padding(16.dp))
            ListItem(headlineContent = { Text("Payload") }, supportingContent = { Text("Buffer: 16 KB/32 KB") })
            ListItem(headlineContent = { Text("Load balancing strategy") }, supportingContent = { Text("Sticky per connection") })
            ListItem(headlineContent = { Text("SOCKS engine") }, supportingContent = { Text("Engine type, UDP support, and BadVPN UDPGW port.") })
            ListItem(headlineContent = { Text("VPN behavior") }, supportingContent = { Text("IPv4/IPv6 DNS, fallback DNS, MTU, IPv6, per-app VPN") })
        }
    }
}
