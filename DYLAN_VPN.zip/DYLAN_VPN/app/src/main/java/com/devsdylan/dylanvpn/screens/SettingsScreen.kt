package com.devsdylan.dylanvpn.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal

@Composable
fun SettingsScreen() {
    val settings by Store.settings.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Les réglages s'appliquent à la prochaine connexion.",
            color = Color.Gray,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)
        )

        SectionTitle("Affichage")
        ChoiceRow(
            title = "Unité de vitesse",
            current = settings.speedUnit,
            options = listOf("bps" to "Bits par seconde (Kbps, Mbps)", "Bps" to "Octets par seconde (Ko/s, Mo/s)"),
            onSelect = { value -> Store.updateSettings { it.copy(speedUnit = value) } }
        )
        ChoiceRow(
            title = "Limite des journaux",
            current = settings.logLimit,
            options = listOf(200 to "200 lignes", 500 to "500 lignes", 1000 to "1000 lignes", 2000 to "2000 lignes"),
            onSelect = { value -> Store.updateSettings { it.copy(logLimit = value) } }
        )

        SectionTitle("Connexion")
        ChoiceRow(
            title = "Serveur DNS",
            current = settings.dns,
            options = listOf(
                "1.1.1.1" to "Cloudflare (1.1.1.1)",
                "8.8.8.8" to "Google (8.8.8.8)",
                "9.9.9.9" to "Quad9 (9.9.9.9)",
                "94.140.14.14" to "AdGuard (94.140.14.14)"
            ),
            onSelect = { value -> Store.updateSettings { it.copy(dns = value) } }
        )
        ChoiceRow(
            title = "MTU",
            current = settings.mtu,
            options = listOf(1280 to "1280", 1400 to "1400", 1500 to "1500 (par défaut)"),
            onSelect = { value -> Store.updateSettings { it.copy(mtu = value) } }
        )
        ChoiceRow(
            title = "Synchronisation au démarrage",
            current = settings.autoSync,
            options = listOf(true to "Activée", false to "Désactivée"),
            onSelect = { value -> Store.updateSettings { it.copy(autoSync = value) } }
        )
        ChoiceRow(
            title = "Vérification de la connexion",
            current = settings.connCheck,
            options = listOf(true to "Activée", false to "Désactivée"),
            onSelect = { value -> Store.updateSettings { it.copy(connCheck = value) } }
        )
        ChoiceRow(
            title = "Niveau de journal du core",
            current = settings.coreLogLevel,
            options = listOf(
                "none" to "Aucun",
                "error" to "Erreurs",
                "warning" to "Avertissements",
                "info" to "Informations",
                "debug" to "Débogage"
            ),
            onSelect = { value -> Store.updateSettings { it.copy(coreLogLevel = value) } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = Pal.Accent,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun <T> ChoiceRow(
    title: String,
    current: T,
    options: List<Pair<T, String>>,
    onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val currentLabel = options.firstOrNull { it.first == current }?.second ?: current.toString()

    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(currentLabel, color = Color.Gray) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { open = true }
    )

    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column {
                    for (option in options) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelect(option.first)
                                    open = false
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = option.first == current,
                                onClick = {
                                    onSelect(option.first)
                                    open = false
                                }
                            )
                            Text(option.second)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { open = false }) { Text("Fermer") }
            }
        )
    }
}
