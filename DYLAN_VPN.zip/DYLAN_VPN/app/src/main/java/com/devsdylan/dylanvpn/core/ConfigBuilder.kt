package com.devsdylan.dylanvpn.core

import org.json.JSONArray
import org.json.JSONObject

/** Construit la configuration JSON de Xray (entrée TUN + sortie « proxy »). */
object ConfigBuilder {

    /**
     * [resolvedIp] : adresse IP déjà résolue du serveur (si son adresse est un nom de domaine).
     * Elle est transmise à Xray via « dns.hosts » pour qu'il n'ait pas à résoudre le nom lui-même.
     */
    fun build(link: ServerLink, resolvedIp: String?, mtu: Int, logLevel: String): String {
        val root = JSONObject()
        root.put("stats", JSONObject())
        root.put("log", JSONObject().put("loglevel", logLevel))
        root.put(
            "policy",
            JSONObject()
                .put(
                    "levels",
                    JSONObject().put(
                        "8",
                        JSONObject()
                            .put("handshake", 4)
                            .put("connIdle", 300)
                            .put("uplinkOnly", 1)
                            .put("downlinkOnly", 1)
                    )
                )
                .put(
                    "system",
                    JSONObject()
                        .put("statsOutboundUplink", true)
                        .put("statsOutboundDownlink", true)
                )
        )
        root.put("inbounds", JSONArray().put(tunInbound(mtu)))
        root.put(
            "outbounds",
            JSONArray()
                .put(proxyOutbound(link, link.host))
                .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
                .put(JSONObject().put("tag", "block").put("protocol", "blackhole"))
        )
        root.put(
            "routing",
            JSONObject().put("domainStrategy", "AsIs").put("rules", JSONArray())
        )
        val hosts = JSONObject()
        if (!resolvedIp.isNullOrBlank() && resolvedIp != link.host) {
            hosts.put(link.host, resolvedIp)
        }
        root.put("dns", JSONObject().put("hosts", hosts).put("servers", JSONArray()))
        return root.toString()
    }

    private fun tunInbound(mtu: Int): JSONObject =
        JSONObject()
            .put("tag", "tun")
            .put("protocol", "tun")
            .put(
                "settings",
                JSONObject().put("name", "xray0").put("MTU", mtu).put("userLevel", 8)
            )
            .put(
                "sniffing",
                JSONObject()
                    .put("enabled", true)
                    .put("destOverride", JSONArray().put("http").put("tls").put("quic"))
            )

    private fun proxyOutbound(link: ServerLink, address: String): JSONObject {
        val out = JSONObject().put("tag", "proxy").put("protocol", protocolName(link))
        out.put("settings", outboundSettings(link, address))
        out.put("streamSettings", streamSettings(link))
        out.put("mux", JSONObject().put("enabled", false))
        return out
    }

    private fun protocolName(link: ServerLink): String =
        when (link.protocol) {
            "ss" -> "shadowsocks"
            else -> link.protocol
        }

    private fun outboundSettings(link: ServerLink, address: String): JSONObject {
        val p = link.params
        return when (link.protocol) {
            "vless" -> {
                val user = JSONObject()
                    .put("id", link.secret)
                    .put("encryption", p["encryption"]?.ifBlank { "none" } ?: "none")
                    .put("level", 8)
                val flow = p["flow"]
                if (!flow.isNullOrBlank()) user.put("flow", flow)
                JSONObject().put(
                    "vnext",
                    JSONArray().put(
                        JSONObject()
                            .put("address", address)
                            .put("port", link.port)
                            .put("users", JSONArray().put(user))
                    )
                )
            }
            "vmess" -> {
                val user = JSONObject()
                    .put("id", link.secret)
                    .put("alterId", p["aid"]?.toIntOrNull() ?: 0)
                    .put("security", link.method.ifBlank { "auto" })
                    .put("level", 8)
                JSONObject().put(
                    "vnext",
                    JSONArray().put(
                        JSONObject()
                            .put("address", address)
                            .put("port", link.port)
                            .put("users", JSONArray().put(user))
                    )
                )
            }
            "trojan" -> JSONObject().put(
                "servers",
                JSONArray().put(
                    JSONObject()
                        .put("address", address)
                        .put("port", link.port)
                        .put("password", link.secret)
                        .put("level", 8)
                )
            )
            "ss" -> JSONObject().put(
                "servers",
                JSONArray().put(
                    JSONObject()
                        .put("address", address)
                        .put("port", link.port)
                        .put("method", link.method)
                        .put("password", link.secret)
                        .put("level", 8)
                )
            )
            else -> throw IllegalArgumentException("Protocole non pris en charge : ${link.protocol}")
        }
    }

    private fun streamSettings(link: ServerLink): JSONObject {
        val p = link.params
        val network = when (val n = (p["type"] ?: "tcp").lowercase().ifBlank { "tcp" }) {
            "splithttp" -> "xhttp"
            else -> n
        }
        val security = (p["security"] ?: "none").lowercase().ifBlank { "none" }
        val sni = (p["sni"] ?: p["peer"] ?: "").trim()
        val hostParam = (p["host"] ?: "").trim()
        val path = (p["path"] ?: "").ifBlank { "/" }
        val stream = JSONObject().put("network", network)

        when (network) {
            "tcp" -> {
                if ((p["headertype"] ?: "") == "http") {
                    val request = JSONObject()
                        .put("path", JSONArray().put(path))
                        .put(
                            "headers",
                            JSONObject().put(
                                "Host",
                                JSONArray().put(hostParam.ifBlank { link.host })
                            )
                        )
                    stream.put(
                        "tcpSettings",
                        JSONObject().put(
                            "header",
                            JSONObject().put("type", "http").put("request", request)
                        )
                    )
                }
            }
            "ws" -> stream.put(
                "wsSettings",
                JSONObject()
                    .put("path", path)
                    .put(
                        "headers",
                        JSONObject().put(
                            "Host",
                            hostParam.ifBlank { sni.ifBlank { link.host } }
                        )
                    )
            )
            "grpc" -> stream.put(
                "grpcSettings",
                JSONObject()
                    .put("serviceName", p["servicename"] ?: "")
                    .put("multiMode", (p["mode"] ?: "") == "multi")
            )
            "httpupgrade" -> stream.put(
                "httpupgradeSettings",
                JSONObject()
                    .put("path", path)
                    .put("host", hostParam.ifBlank { sni.ifBlank { link.host } })
            )
            "xhttp" -> stream.put(
                "xhttpSettings",
                JSONObject()
                    .put("path", path)
                    .put("host", hostParam.ifBlank { sni.ifBlank { link.host } })
                    .put("mode", (p["mode"] ?: "").ifBlank { "auto" })
            )
            else -> throw IllegalArgumentException("Transport non pris en charge : $network")
        }

        when (security) {
            "tls" -> {
                stream.put("security", "tls")
                val tls = JSONObject()
                    .put("serverName", sni.ifBlank { hostParam.ifBlank { link.host } })
                val alpn = (p["alpn"] ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (alpn.isNotEmpty()) {
                    val arr = JSONArray()
                    for (a in alpn) arr.put(a)
                    tls.put("alpn", arr)
                }
                val fp = p["fp"]
                if (!fp.isNullOrBlank()) tls.put("fingerprint", fp)
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                val pbk = p["pbk"] ?: ""
                if (pbk.isBlank()) {
                    throw IllegalArgumentException("Lien Reality incomplet : clé publique (pbk) manquante")
                }
                stream.put("security", "reality")
                val reality = JSONObject()
                    .put("serverName", sni.ifBlank { link.host })
                    .put("fingerprint", (p["fp"] ?: "").ifBlank { "chrome" })
                    .put("publicKey", pbk)
                    .put("shortId", p["sid"] ?: "")
                    .put("spiderX", p["spx"] ?: "")
                val pqv = p["pqv"]
                if (!pqv.isNullOrBlank()) reality.put("mldsa65Verify", pqv)
                stream.put("realitySettings", reality)
            }
            "none" -> {}
            else -> throw IllegalArgumentException("Sécurité non prise en charge : $security")
        }
        return stream
    }
}
