package com.devsdylan.dylanvpn

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.devsdylan.dylanvpn.core.IoUtil
import com.devsdylan.dylanvpn.screens.importAndToast
import com.devsdylan.dylanvpn.ui.MainNavigation
import com.devsdylan.dylanvpn.ui.Pal

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncoming(intent)
        setContent {
            val darkScheme = darkColorScheme(
                primary = Pal.Accent,
                onPrimary = Color(0xFF002111),
                background = Pal.Bg,
                surface = Pal.Card,
                surfaceVariant = Pal.CardHi,
                onBackground = Pal.Text,
                onSurface = Pal.Text
            )
            MaterialTheme(colorScheme = darkScheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainNavigation()
                }
            }
        }
    }

    /** Ouverture d'un fichier .dyl depuis un gestionnaire de fichiers, WhatsApp, etc. : les configs sont importées. */
    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            @Suppress("DEPRECATION")
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri == null) return
        Thread {
            val text = try {
                contentResolver.openInputStream(uri)?.use { String(IoUtil.readLimited(it, 1_000_000), Charsets.UTF_8) } ?: ""
            } catch (e: Exception) {
                ""
            }
            runOnUiThread { importAndToast(this, text) }
        }.start()
    }
}
