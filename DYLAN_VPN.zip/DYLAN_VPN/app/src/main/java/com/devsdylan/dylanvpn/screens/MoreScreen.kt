package com.devsdylan.dylanvpn.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.data.Account
import com.devsdylan.dylanvpn.ui.Pal
import com.devsdylan.dylanvpn.ui.SyncBar

@Composable
fun MoreScreen(onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val session by Account.session.collectAsStateWithLifecycle()

    fun openSystem(action: String) {
        try {
            context.startActivity(Intent(action))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Ce réglage n'est pas disponible sur cet appareil", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        session?.let {
            MoreCard {
                Text("Compte", color = Pal.Sub)
                Text(it.login + " · " + categoryLabel(it.category), style = MaterialTheme.typography.titleMedium, color = Pal.Accent)
                SyncBar()
            }
        }
        MoreRow("Journaux", "Détails de la connexion et des erreurs") { onNavigate("logs") }
        MoreRow("Partage de connexion", "Créer un point d'accès Wi-Fi et partager le VPN") { onNavigate("share") }
        MoreRow("Applications", "Choisir quelles applications passent par le VPN") { onNavigate("apps") }
        MoreRow("Optimisation de la batterie", "Autoriser DYLAN VPN à rester actif en arrière-plan") {
            openSystem(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        }
        MoreRow("Profils VPN du système", "Ouvrir les réglages VPN d'Android (VPN permanent, suppression)") {
            openSystem(Settings.ACTION_VPN_SETTINGS)
        }
        if (session?.category == "admin") {
            MoreRow("Admin", "Utilisateurs, configs par catégorie, dépôt Git") { onNavigate("admin") }
        }
        MoreRow("Guide", "Premiers pas et explications") { onNavigate("guide") }
        MoreRow("À propos", "Version, core Xray, ID de l'appareil") { onNavigate("about") }
        MoreRow("Se déconnecter", "Revenir à l'écran de connexion") { Account.logout() }
    }
}

fun categoryLabel(category: String): String =
    when (category) {
        "basic" -> "Basic"
        "pro" -> "Pro"
        "admin" -> "Admin"
        else -> category
    }

@Composable
private fun MoreCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Card)
    ) {
        Column(modifier = Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun MoreRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Card)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Pal.Text)
            Text(subtitle, color = Pal.Sub)
        }
    }
}
