package com.devsdylan.dylanvpn.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devsdylan.dylanvpn.core.CoreRuntime
import com.devsdylan.dylanvpn.data.Profile
import com.devsdylan.dylanvpn.data.Store
import com.devsdylan.dylanvpn.ui.Pal
import com.devsdylan.dylanvpn.util.Format

/** Types de lien proposés à l'import : (protocole, libellé, exemple). */
private val IMPORT_TYPES = listOf(
    Triple("dylan", "Dylan", "dylan://..."),
    Triple("vless", "VLESS", "vless://..."),
    Triple("vmess", "VMess", "vmess://..."),
    Triple("trojan", "Trojan", "trojan://..."),
    Triple("ss", "Shadowsocks", "ss://...")
)

@Composable
fun ProfilesScreen() {
    val context = LocalContext.current
    val profiles by Store.profiles.collectAsStateWithLifecycle()
    val selectedId by Store.selectedId.collectAsStateWithLifecycle()
    val tests by CoreRuntime.tests.collectAsStateWithLifecycle()
    var showTypes by remember { mutableStateOf(false) }
    var importType by remember { mutableStateOf<String?>(null) }
    var toDelete by remember { mutableStateOf<Profile?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (profiles.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Outlined.Description, contentDescription = null, tint = Pal.Sub, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(16.dp))
                Text("Aucun profil enregistré", color = Pal.Text, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Appuie sur + pour importer un lien Dylan, VLESS, VMess, Trojan ou Shadowsocks.",
                    color = Pal.Sub
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    val isSelected = profile.id == selectedId
                    val result = tests[profile.id]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { Store.select(profile.id) },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Pal.Card),
                        border = if (isSelected) BorderStroke(1.5.dp, Pal.Accent) else null
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) Pal.Accent else Pal.CardHi),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    profile.protocol.uppercase().take(2),
                                    color = if (isSelected) Pal.Bg else Pal.Accent
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(profile.name, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (profile.locked) "Config verrouillée" else profile.protocol.uppercase() + " · " + profile.host + ":" + profile.port,
                                    color = Pal.Sub,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (profile.expiresAt > 0) {
                                    val left = profile.expiresAt - Store.now()
                                    Text(
                                        if (left <= 0) "Expirée" else "Expire dans " + Format.remaining(left),
                                        color = if (left <= 0) Pal.Red else Pal.Amber
                                    )
                                }
                                if (profile.limits.active) {
                                    Text(
                                        "Débit limité · ↓ " + Format.limit(profile.limitDown) + " · ↑ " + Format.limit(profile.limitUp),
                                        color = Pal.Sub
                                    )
                                }
                                if (result != null) {
                                    Text(
                                        result,
                                        color = if (result.startsWith("OK")) Pal.Green
                                        else if (result.startsWith("Test")) Pal.Amber
                                        else Pal.Red
                                    )
                                }
                            }
                            IconButton(onClick = { CoreRuntime.test(context, profile) }) {
                                Icon(Icons.Default.NetworkCheck, contentDescription = "Tester", tint = Pal.Accent)
                            }
                            IconButton(onClick = { toDelete = profile }) {
                                Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = Pal.Sub)
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showTypes = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = Pal.Accent,
            contentColor = Pal.Bg
        ) {
            Icon(Icons.Default.Add, contentDescription = "Importer")
        }
    }

    if (showTypes) {
        AlertDialog(
            onDismissRequest = { showTypes = false },
            title = { Text("Importer un profil") },
            text = {
                Column {
                    Text("Quel type de lien veux-tu importer ?", color = Pal.Sub)
                    Spacer(Modifier.height(8.dp))
                    for (type in IMPORT_TYPES) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showTypes = false
                                    importType = type.first
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Pal.CardHi),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type.second.take(2).uppercase(), color = Pal.Accent)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(type.second, color = Pal.Text)
                                Text(type.third, color = Pal.Sub)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showTypes = false
                                importType = "auto"
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Pal.CardHi),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, tint = Pal.Accent, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Détection automatique", color = Pal.Text)
                            Text("Plusieurs liens de types différents", color = Pal.Sub)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTypes = false }) { Text("Annuler") }
            }
        )
    }

    val type = importType
    if (type != null) {
        ImportDialog(type = type, onDismiss = { importType = null })
    }

    val target = toDelete
    if (target != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Supprimer ce profil ?") },
            text = { Text(target.name) },
            confirmButton = {
                TextButton(onClick = {
                    Store.deleteProfile(target.id)
                    toDelete = null
                }) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun ImportDialog(type: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val label = IMPORT_TYPES.firstOrNull { it.first == type }?.second ?: "tous types"
    val hint = IMPORT_TYPES.firstOrNull { it.first == type }?.third ?: "vless://, vmess://, trojan://, ss://"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importer : $label") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        error = ""
                    },
                    label = { Text("Lien ($hint)") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = {
                    val pasted = clipboard.getText()?.text
                    if (!pasted.isNullOrBlank()) {
                        text = pasted
                        error = ""
                    }
                }) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Coller depuis le presse-papiers")
                }
                if (error.isNotEmpty()) {
                    Text(error, color = Pal.Red)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val expected = if (type == "auto") null else type
                val result = Store.addProfiles(text, expected)
                if (result.added > 0) {
                    val skipped = if (result.errors.isEmpty()) "" else " (" + result.errors.size + " ignoré(s))"
                    Toast.makeText(context, result.added.toString() + " profil(s) ajouté(s)" + skipped, Toast.LENGTH_SHORT).show()
                    onDismiss()
                } else {
                    error = result.errors.firstOrNull() ?: "Aucun lien trouvé"
                }
            }) { Text("Importer") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
