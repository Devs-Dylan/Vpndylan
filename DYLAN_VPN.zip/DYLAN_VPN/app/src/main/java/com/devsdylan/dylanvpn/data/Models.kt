package com.devsdylan.dylanvpn.data

data class Profile(
    val id: String,
    val name: String,
    val link: String,
    val protocol: String,
    val host: String,
    val port: Int
)

data class AppSettings(
    val speedUnit: String = "bps",
    val logLimit: Int = 1000,
    val mtu: Int = 1500,
    val dns: String = "1.1.1.1",
    val coreLogLevel: String = "warning"
)

data class AddResult(val added: Int, val errors: List<String>)
