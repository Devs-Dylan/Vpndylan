package com.devsdylan.dylanvpn.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class VpnStatus { IDLE, CONNECTING, CONNECTED, ERROR }

data class VpnUiState(val status: VpnStatus = VpnStatus.IDLE, val message: String = "")

/** État partagé entre le service VPN et l'interface. */
object VpnState {
    private val _state = MutableStateFlow(VpnUiState())
    val state: StateFlow<VpnUiState> = _state

    fun set(status: VpnStatus, message: String = "") {
        _state.value = VpnUiState(status, message)
    }
}
