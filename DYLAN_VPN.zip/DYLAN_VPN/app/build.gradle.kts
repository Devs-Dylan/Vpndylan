plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Jeton GitHub en LECTURE SEULE embarqué dans l'application (sert à lire les configs chiffrées).
// Source, dans l'ordre : propriété Gradle, variable d'environnement, fichier git_read_token.txt
// (à la racine du dépôt GitHub, ou dans le dossier du projet). Jamais le jeton d'écriture.
val gitReadToken: String = run {
    val raw = (project.findProperty("GIT_READ_TOKEN") as String?)?.trim()
        ?: System.getenv("GIT_READ_TOKEN")?.trim()
        ?: listOf(
            File(rootProject.projectDir, "git_read_token.txt"),
            File(rootProject.projectDir.parentFile, "git_read_token.txt")
        ).firstOrNull { it.exists() }?.readText()?.trim()
        ?: ""
    raw.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
}

android {
    namespace = "com.devsdylan.dylanvpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.devsdylan.dylanvpn"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.1.0"
        buildConfigField("String", "GIT_READ_TOKEN", "\"" + gitReadToken + "\"")
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

// Télécharge automatiquement le core Xray s'il manque (nécessite Internet, ~60 Mo).
val libv2rayFile = layout.projectDirectory.file("libs/libv2ray.aar").asFile
val downloadLibv2ray by tasks.registering {
    outputs.file(libv2rayFile)
    onlyIf { !libv2rayFile.exists() }
    doLast {
        libv2rayFile.parentFile.mkdirs()
        val part = File(libv2rayFile.parentFile, "libv2ray.aar.part")
        val url = "https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.10.21/libv2ray.aar"
        uri(url).toURL().openStream().use { input ->
            part.outputStream().use { output -> input.copyTo(output) }
        }
        part.renameTo(libv2rayFile)
    }
}
tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(downloadLibv2ray)
}

dependencies {
    // Core Xray (AndroidLibXrayLite). Le fichier est téléchargé par le workflow GitHub Actions
    // ou à la main : voir le README.
    implementation(files("libs/libv2ray.aar"))
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
}
