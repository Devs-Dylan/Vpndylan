package com.epro.httpcustom.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Traffic", color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Download", color = Color(0xFF4FC3F7))
                        Text("0 bps", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Peak 0 bps", color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Upload", color = Color(0xFFFFAB91))
                        Text("0 bps", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Peak 0 bps", color = Color.Gray)
                    }
                }
                AssistChip(onClick = {}, label = { Text("Idle") })
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Main connection", color = Color.White)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Single tunnel", color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = true, onClick = {}, label = { Text("V2Ray") })
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {}) { Text("View") }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        FloatingActionButton(
            onClick = { /* TODO: Connect / Disconnect V2Ray */ },
            modifier = Modifier.align(Alignment.End),
            containerColor = Color(0xFF1976D2)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Connect")
        }
    }
}
