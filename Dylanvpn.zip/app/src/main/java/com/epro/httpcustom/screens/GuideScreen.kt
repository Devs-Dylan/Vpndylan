package com.epro.httpcustom.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun GuideScreen() {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2A3A5A))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Guide", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Text("Quick reference for using the app, tokens, and remote proxy format.", color = Color.LightGray)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Basic operation", color = Color.White)
                    Text("1. Choose a protocol from Home or the drawer.")
                    Text("2. Fill the server, account, and protocol options.")
                    Text("3. Enable Payload, SSL/SNI, or SlowDNS only when your server needs it.")
                    Text("4. Save the setup as a profile, choose it, then use the connection button on Home.")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Tokens format", color = Color.White)
                    Text("Server: [host] [server] [port] [host_port] [ip] [ip_port]")
                    Spacer(Modifier.height(8.dp))
                    Text("Per-protocol: [ssh] [v2ray] [openvpn] [psiphon] [udp_custom] ...")
                }
            }
        }
    }
}
