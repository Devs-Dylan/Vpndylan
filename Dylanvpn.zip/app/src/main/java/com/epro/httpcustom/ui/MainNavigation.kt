package com.epro.httpcustom.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.epro.httpcustom.screens.GuideScreen
import com.epro.httpcustom.screens.HomeScreen
import com.epro.httpcustom.screens.ProfilesScreen
import com.epro.httpcustom.screens.SettingsScreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF1A1A1A)) {
                // Drawer content matching HTTP Custom
                Text("2026 © ePro Dev Team", modifier = Modifier.padding(16.dp), color = Color.White)
                Text("v7.11.28 - Patch 1 (899)", color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp))
                HorizontalDivider(color = Color.DarkGray)
                NavigationDrawerItem(label = { Text("SSH") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("V2Ray") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("Psiphon") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("OpenVPN") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("UDP Custom") }, selected = false, onClick = { })
                HorizontalDivider(color = Color.DarkGray)
                Text("Utility", color = Color(0xFF4FC3F7), modifier = Modifier.padding(16.dp))
                NavigationDrawerItem(label = { Text("IP Finder") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("Auto Ping") }, selected = false, onClick = { })
                NavigationDrawerItem(label = { Text("About") }, selected = false, onClick = { })
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF1A1A1A)) {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "profiles",
                        onClick = { navController.navigate("profiles") },
                        icon = { Icon(Icons.Outlined.List, null) },
                        label = { Text("Profiles") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "settings",
                        onClick = { navController.navigate("settings") },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "guide",
                        onClick = { navController.navigate("guide") },
                        icon = { Icon(Icons.Outlined.Book, null) },
                        label = { Text("Guide") }
                    )
                }
            },
            topBar = {
                TopAppBar(
                    title = { Text(currentRoute?.replaceFirstChar { it.uppercase() } ?: "Dylanvpn", color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1A1A1A))
                )
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                composable("home") { HomeScreen() }
                composable("profiles") { ProfilesScreen() }
                composable("settings") { SettingsScreen() }
                composable("guide") { GuideScreen() }
            }
        }
    }
}
