# Dylanvpn

Projet Android Kotlin (Jetpack Compose) inspiré de HTTP Custom, renommé **Dylanvpn**.

## État actuel
- Interface dark theme proche des screenshots (Home, Profiles, Settings, Guide, Drawer)
- Bottom navigation
- Structure prête pour extension
- **Pas de vrai core V2Ray intégré** (trop complexe pour être inclus automatiquement)

## Pour avoir un vrai client V2Ray fonctionnel
1. Ouvre ce projet dans Android Studio
2. Intègre un core open-source :
   - [v2rayNG](https://github.com/2dust/v2rayNG) (le plus mature)
   - ou [sing-box](https://github.com/SagerNet/sing-box)
   - ou [NekoBox](https://github.com/MatsuriDayo/NekoBoxForAndroid)
3. Ajoute le VpnService + gestion des configs V2Ray/VLESS/Trojan

## Comment compiler
1. Ouvre le dossier dans Android Studio
2. Sync Gradle
3. Run sur un téléphone ou émulateur

**Note** : L'app actuelle est principalement une interface. La connexion réelle nécessite l'intégration d'un core natif.
